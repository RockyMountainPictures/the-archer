import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import ddf.minim.*; 
import controlP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class The_Archer extends PApplet {

/*
Assignment 4 - Archer
By: Max Nielsen
IAT 167 - D102
17-03-2022

Hi Amineh and Others!

--- Backstory (also in the game): ---

Welcome to The Archer, where you play as King Alcinous of Esqueria. 
You are delivering a message of importance to the village Polt, warning them of an attack.
However, the village has disappeared! Your goal is to recover the citizens of Polt and 
defeat the evil that attacked your village.


--- Controls (also in the game): ---

Move - A & D
Run - Hold Shift while moving
Jump - Space
Double Jump - Space
  After jumping while you're accelerating up.
Lunge - Space
  After jumping while you're accelerating down due to gravity and you're moving or running.
Interact - E 
  Hold down to move the broken portal piece in Level One. Otherwise, it's just a tap.
Shoot - Left Mouse Button
  Hold down to draw the bow, let go to shoot. Auto shoots after one second.
Toggle Trajectory - Right Mouse Button
  Tapping RMB toggles the arc shown when drawn, to add a layer of difficulty.
Pause - Esc
  Shows controls, allows you to restart, and resume game with button or pressing Esc again.
Inventory - Tab (Decommissioned)
  Was going to add items, powerups, and statistics that would be displayed here.


With that, enjoy the game!
Cheers,
Max
*/

// --- Libraries --- //



// --- Constants --- //
// Highest level game states
final int START = 0;
final int GAMEPLAY = 1;
final int NARRATIVE = 2;
final int SLEEP = 3;
final int WON = 8;
final int LOST = 9;
final int PAUSE = 10;

// Holding game states
int state = START;
int prevState;

// --- Assets --- //
PFont font, fontBold, fontItalic, fontBoldItalic;
PImage[] spritesEnviro, spritesEnemy, spritesProjectiles, spritesInteractables, spritesUI, spritesOther;
PImage[] sprCharIdle, sprCharMove, sprCharJump, sprCharDash, sprCharAtk1, sprCharAtk2, sprCharRedIdle, sprCharRedMove, sprCharRedJump;
PImage[] sprWitchIdle, sprWitchMove, sprWitchAtk, sprWitchDie;
PImage[] sprPlasma, sprArrow;
PImage[] sprGem;
PImage[] sprPortalGreenOpen, sprPortalGreenIdle, sprPortalGreenFrame;
PImage[] sprPortalBlueOpen, sprPortalBlueIdle, sprPortalBlueFrame;
PImage[] sprBackgrounds;
Minim minim;  // Sounds
AudioPlayer[] sfxShoot, sfxChar, sfxGem, sfxPortal, sfxBackground;


// --- Entities --- //
ArrayList<Enemy> enemies = new ArrayList<Enemy>();
ArrayList<Interactable> interactables = new ArrayList<Interactable>();
Char player;

// --- UI/UX Stuff --- //
UI ui;
boolean showControls = false;
// Buttons
ControlP5 controlP5;
Button play, restart, controls, resume, quit, leave, restartLevel, menu;

// --- Background Stuff --- //
PImage currBG;
float groundLevel = 113;
float bgWidth;
float bgSpeed = 4;
float offset = 0;



// ***   Methods   *** //

// Setup: Initializing all the assets, entities, and UI things.
public void setup() {
  
  colorMode(RGB, 255, 255, 255, 60);  // Alpha is set to 60 to match frame rate 
  state = START;  // Starting the game at the start :>
  
  initSprites();
  initChar();
  initInteractables();
  initSounds();
  initOther();
  initButtons();
}

// Draw: Handling the highest level game states. It branches out through the methods in each case
public void draw() {
  switch(state) {
    case(START):
      ui.renderStartScreen();
      break;
    case(GAMEPLAY):
      updateGameplay();
      break;
    case(NARRATIVE):
      updateNarrative();
      break;
    case(SLEEP):
      updateSleep();
      break;
    case(WON):
      ui.renderWinScreen();
      break;
    case(LOST):
      updateLoseScreen();
      break;
    case(PAUSE):
      updatePause();
  }
}

// Updates all gameplay elements of entities (movement, health, states, etc.)
public void update() {
  player.update();
  updateEnemies();
  updateInteractables();
}

// Updates and renders everything when player is able to move around, kill enemies, etc.
public void updateGameplay() {
  update();
  renderBackground();
  renderForeground();
  renderEntities();
  renderUI();
  handleGameplaySwitches();
  handleSwitches();
  player.handleSounds();
}

// Shows a losing screen overlay when player dies
public void updateLoseScreen() {
  update();
  renderBackground();
  renderForeground();
  renderEntities();
  ui.renderLoseScreen();
}

// Updates and renders everything during narrative aspects of the game
public void updateNarrative() {
  player.handleGravity();
  renderBackground();
  renderForeground();
  renderEntities();
  renderUI();
  handleNarrativeSwitches();
  handleSwitches();
  player.handleSounds();
}

// Updates and renders everything when player sleeps in camp to regain health
public void updateSleep() {
  updateInteractables();
  renderBackground();
  renderForeground();
  renderEntities();
  handleSwitches();
}

// Freezes entities and only renders them while paused
public void updatePause() {
  // Show buttons
  resume.show();
  controls.show();
  restart.show();
  
  // Render necessary parts
  renderBackground();
  renderForeground();
  renderEntities();
  ui.renderPauseScreen();
  
  // Stop sounds
  sfxChar[0].pause();
  sfxChar[1].pause();
  sfxBackground[0].pause();
}

// Updates movement and health of enemies
public void updateEnemies() {
  for (int i = 0; i < enemies.size(); i++)
    enemies.get(i).update();
}

// Updates position and states of interactables
public void updateInteractables() {
  for(int i = 0; i < interactables.size(); i++)
    interactables.get(i).update();
}

// Restarts the game completely when button is pressed
public void handleRestart() {
  handleUnpause();
  
  // Clear entities, Reset UI
  interactables.clear();
  enemies.clear();
  player = null;
  ui = null;
  showControls = false;
  
  // Re-initialize everything from setup
  initChar();
  initInteractables();
  initOther();
  initButtons();
  
  // Reset all states to defaults
  state = START;
  level = LVL_1;
  resetGameNarrStates();
  
  // Reset odd variables
  groundLevel = 113;
}

// Resets all narration and gameplay stages of each level
public void resetGameNarrStates() {
  narrOneLevel = LVL_1;
  narrTwoLevel = LVL_1;
  narrThreeLevel = LVL_1;
  narrFourLevel = LVL_1;
  gameOneLevel = LVL_1;
  gameTwoLevel = LVL_1;
  gameThreeLevel = LVL_1;
  gameFourLevel = LVL_1;
}

// Restarts game from the level you died in
public void handleRestartLevel() {
  // Hide buttons and reset colours
  restart.hide();
  restartLevel.hide();
  restart.setColorLabel(color(250));
  restartLevel.setColorLabel(color(250));
  
  // Reset all states except level to defaults
  state = prevState;
  prevState = LOST;
  resetGameNarrStates();
  
  // Clear enemies
  enemies.clear();
  
  // Reset odd variables
  paused = false;
  
  // Handle particular level resets
  switch(level) {
    case(LVL_1):  // Resets everything similar to full reset because it's the first level
      player = null;
      ui = null;
      interactables.clear();
      initInteractables();
      initChar();
      initOther();
      break;
    case(LVL_2):
      groundLevel = 83;
      resetPlayer(new PVector(200, groundLevel));
      
      // Reset positions of set interactables (portals, camp)
      interactables.get(1).pos = new PVector(player.pos.x, height - groundLevel - interactables.get(1).sprite.height/2);
      interactables.get(0).pos = new PVector(width, height - groundLevel + 7 - interactables.get(0).sprite.height/2);
      interactables.get(2).pos = new PVector(5250, height - groundLevel - sprPortalBlueFrame[0].height/2);
      
      // Reset player inventory to the correct amount of gems before Level Two
      if(player.getGemCount() > 1) {
        for(int i = 1; i < player.getGemCount(); i++)
          player.inventory.remove(i);
      }
      break;
    case(LVL_3):
      groundLevel = 145;
      resetPlayer(new PVector(200, groundLevel));
      
      // Reset positions of set interactables (portals, camp)
      interactables.get(1).pos = new PVector(width/2, -5000);
      interactables.get(0).pos = new PVector(width, height - groundLevel + 7 - interactables.get(0).sprite.height/2);
      interactables.get(2).pos = new PVector(player.pos.x, height - groundLevel - interactables.get(2).sprite.height/2);
      break;
  }
  state = GAMEPLAY;
}

// Resets player variables
public void resetPlayer(PVector pos) {
  player.pos = pos;
  player.health = new PVector(5, 4);
  player.activeFrames = sprCharIdle;
  player.spriteCurrent = sprCharIdle[0];
  player.isAlive = true;
  player.alpha = 60;
  player.arrows.clear();
}

// Remove buttons and change states back to unpaused
public void handleUnpause() {
  // Hide all buttons and reset colours of buttons clicked
  resume.hide();
  controls.hide();
  restart.hide();
  restartLevel.hide();
  menu.hide();
  quit.hide();
  resume.setColorLabel(color(250));
  restart.setColorLabel(color(250));
  menu.setColorLabel(color(250));
  quit.setColorLabel(color(250));
  restartLevel.setColorLabel(color(250));
  if(!showControls)  // Special case for toggleable view of the controls in pause menu
    controls.setColorLabel(color(250));
    
  // Unpause and set state
  paused = false;
  state = prevState;
  prevState = PAUSE;
  println("UI: Resuming game...");
  
  // Restart background sound
  sfxBackground[0].play();
}
// Initialize Sprites
public void initSprites() {
  println("MESSAGE: Initializing sprites...");
  
  // Character Sprites
  sprCharIdle = new PImage[2];
  sprCharMove = new PImage[8];
  sprCharJump = new PImage[10];
  sprCharAtk1 = new PImage[11];
  sprCharAtk2 = new PImage[11];
  loadSpriteFrames(sprCharIdle, "Char/Idle/CharIdle_");
  loadSpriteFrames(sprCharMove, "Char/Move/CharMove_");
  loadSpriteFrames(sprCharJump, "Char/Jump/CharJump_");
  loadSpriteFrames(sprCharAtk1, "Char/Atk1/CharAtk1_");
  loadSpriteFrames(sprCharAtk2, "Char/Atk2/CharAtk2_");
  
  // Character Sprites - Red Bow
  sprCharRedIdle = new PImage[2];
  sprCharRedMove = new PImage[8];
  sprCharRedJump = new PImage[10];
  loadSpriteFrames(sprCharRedIdle, "Char/RedBow/Idle/CharIdle_");
  loadSpriteFrames(sprCharRedMove, "Char/RedBow/Move/CharMove_");
  loadSpriteFrames(sprCharRedJump, "Char/RedBow/Jump/CharJump_");
  
  // Monster Sprites
  sprWitchIdle = new PImage[7];
  sprWitchMove = new PImage[8];
  sprWitchAtk = new PImage[14];
  sprWitchDie = new PImage[12];
  loadSpriteFrames(sprWitchIdle, "Enemies/Witch/Idle/WitchIdle_");
  loadSpriteFrames(sprWitchMove, "Enemies/Witch/Move/WitchMove_");
  loadSpriteFrames(sprWitchAtk, "Enemies/Witch/Atk/WitchAttack_");
  loadSpriteFrames(sprWitchDie, "Enemies/Witch/Die/WitchDie_");
  
  // Projectile Sprites
  sprPlasma = new PImage[4];
  sprArrow = new PImage[1];
  loadSpriteFrames(sprPlasma, "Projectiles/Plasma/Plasma_");
  loadSpriteFrames(sprArrow, "Projectiles/Arrows/Arrow_");
  
  // Gem Sprites
  sprGem = new PImage[5];
  loadSpriteFrames(sprGem, "Items/Gem/Gem_");
  
  // Portal Sprites - Green/Level One
  sprPortalGreenOpen = new PImage[15];
  sprPortalGreenIdle = new PImage[5];
  sprPortalGreenFrame = new PImage[4];
  loadSpriteFrames(sprPortalGreenFrame, "Portals/Green/Frame/PortalFrame_");
  loadSpriteFrames(sprPortalGreenOpen, "Portals/Green/Open/PortalOpen_");
  loadSpriteFrames(sprPortalGreenIdle, "Portals/Green/Idle/PortalIdle_");
  
  // Portal Sprites - Blue/Level Two
  sprPortalBlueOpen = new PImage[15];
  sprPortalBlueIdle = new PImage[5];
  sprPortalBlueFrame = new PImage[4];
  loadSpriteFrames(sprPortalBlueFrame, "Portals/Blue/Frame/PortalFrame_");
  loadSpriteFrames(sprPortalBlueOpen, "Portals/Blue/Open/PortalOpen_");
  loadSpriteFrames(sprPortalBlueIdle, "Portals/Blue/Idle/PortalIdle_");
  
  // Miscellaneous Sprites
  spritesUI = new PImage[2];
  spritesOther = new PImage[1];
  spritesEnviro = new PImage[3];
  loadSpriteFrames(spritesEnviro, "Backgrounds/bg_");  // Backgrounds for each level
  spritesUI[0] = loadImage("GUI/Controls.png");  // Control scheme
  spritesUI[1] = loadImage("GUI/Key_E.png");  // For letting player know how to advance dialogue
  spritesOther[0] = loadImage("Projectiles/Arrows/Arrow_Big.png");  // For start/pause screen
  
  bgWidth = spritesEnviro[0].width;  // Hold pixel width of background images
  
  println("MESSAGE: Sprite initialization successful.");
}

// Initialize Sounds
public void initSounds() {
  println("MESSAGE: Initializing SFX...");
  
  minim = new Minim(this);
  
  // Load all sounds 
  sfxShoot = new AudioPlayer[9];
  sfxChar = new AudioPlayer[4];
  sfxGem = new AudioPlayer[1];
  sfxPortal = new AudioPlayer[2];
  sfxBackground = new AudioPlayer[1];
  loadSounds(sfxShoot, "Sounds/Bow_");
  loadSounds(sfxChar, "Sounds/Char_");
  loadSounds(sfxGem, "Sounds/Gem_");
  loadSounds(sfxPortal, "Sounds/Portal_");
  loadSounds(sfxBackground, "Sounds/bg_");
  
  // Adjust volumes
  sfxBackground[0].setGain(-15);
  sfxPortal[0].setGain(-10);
  for(int i = 0; i < sfxChar.length; i++)
    sfxChar[i].setGain(-20);
  for(int i = 0; i < sfxShoot.length; i++)
    sfxShoot[i].setGain(-10);
  for(int i = 0; i < sfxGem.length; i++)
    sfxGem[i].setGain(-10);
  
  // Start background music
  playSound(sfxBackground[0]);
  sfxBackground[0].loop(99);  // Loops for 16.5 hours :>
  
  println("MESSAGE: SFX initialization successful.");
}

// Initialize Character
public void initChar() {
  println("MESSAGE: Initializing player...");
  PVector vel = new PVector(0, 0);
  PVector dim = new PVector(100, 132);
  PVector pos = new PVector(200, height - groundLevel - dim.y/2);
  PVector[] bb = {new PVector(44, 132), new PVector(-14.5f, 0)};
  PVector health = new PVector(5, 4);
  PVector maxHealth = new PVector(5, 4);
  player = new Char(pos, vel, dim, bb, health, maxHealth);
  println("MESSAGE: Player initialization successful.");
}

// Initialize Interactables (camp, tent);
public void initInteractables() {
  println("MESSAGE: Initializing interactable objects...");
  // Load campground
  PImage sprite = loadImage("camp.png");
  PVector dim = new PVector(sprite.width, sprite.height);
  PVector pos = new PVector(width, height - groundLevel - sprite.height/2 + 7);
  int range = 100;
  interactables.add(new Checkpoint(pos, dim, sprite, range));
  
  // Load first portal
  PVector portalPos = new PVector(5500, height - groundLevel - sprPortalGreenFrame[0].height/2);
  PVector portalDim = new PVector(256, 256);
  interactables.add(new Portal(portalPos, portalDim, sprPortalGreenFrame, sprPortalGreenOpen, sprPortalGreenIdle));
  println("MESSAGE: Object initialization successful.");
}

// Initialize Other Assets/Variables
public void initOther() {
  println("MESSAGE: Initializing other items...");
  // Fonts
  font = loadFont("BookmanOldStyle-120.vlw");
  fontBold = loadFont("BookmanOldStyle-Bold-120.vlw");
  fontItalic = loadFont("BookmanOldStyle-Italic-120.vlw");
  fontBoldItalic = loadFont("BookmanOldStyle-BoldItalic-120.vlw");
  
  // Miscellaneous
  ui = new UI(player);
  currBG = spritesEnviro[0];
  trajectory = true;
  
  // Set varibles for dialogue boxes
  narrPadding = 25;
  narrAlpha = 60;
  narrDim = new PVector(650, 200);
  narrPos = new PVector(width - spritesUI[1].width - narrPadding*2 - narrDim.x/2, narrPadding + narrDim.y/2);
  println("MESSAGE: Other items initialization successful.");
}

// Initialize Enemies - Called after narration. Not in setup.
// PVector Range: Where to position the enemies relative to the player. x = min value, y = max value
public void initEnemies(int numEnemies, PVector range) {
  println("MESSAGE: Initializing enemies...");
  for (int i = 0; i < numEnemies; i++) {
    PVector vel = new PVector(random(15, 30), 0);
    PVector dim = new PVector(50, 50);
    PVector pos = new PVector(random(dim.x + range.x, range.y - dim.x), height - groundLevel - dim.y/2);
    PVector[] bb = {new PVector(50, 50), new PVector(0, 0)};
    PVector health = new PVector(3, 1);
    int dmg = 1;
    enemies.add(new Enemy(pos, vel, dim, bb, health, dmg));
  }
  println("MESSAGE: Enemy initialization successful.");
}

// Initialize Buttons - Oh so many buttons
public void initButtons() {
  println("MESSAGE: Initializing buttons...");
  int c1 = color(250);  // Text colour
  int c = color(0, 0, 0, .24f);  // Button background colour 
  
  controlP5 = new ControlP5(this);
  
  // Play button
  play = controlP5.addButton("Play", 0, 200, 300, 195, 70);
  play.getCaptionLabel().setFont(font);  // Font
  play.setColorLabel(c1);                // Font colour
  play.setColorForeground(c);            // Can't remember
  play.setColorBackground(c);            // Regular button colour
  play.setColorActive(c);                // Hover button colour
  play.getCaptionLabel().setSize(72);    // Font size
  play.getCaptionLabel().alignX(ControlP5.LEFT);  // Font alignment
  // When hovering...
  play.onEnter(new CallbackListener() { public void controlEvent(CallbackEvent theEvent) {
    play.setColorLabel(0xff9c5b30);
  } } );
  // When leaving button...
  play.onLeave(new CallbackListener() { public void controlEvent(CallbackEvent theEvent) {
    play.setColorLabel(color(250));
  } } );
  // When clicked... play the game
  play.onClick(new CallbackListener() { public void controlEvent(CallbackEvent theEvent) {
    play.hide();
    controls.hide();
    quit.hide();
    state = GAMEPLAY;
  } } );
  
  // Quit button
  quit = controlP5.addButton("Quit", 0, 200, 372 + 20 + 72, 195, 70);
  quit.getCaptionLabel().setFont(font);
  quit.setColorLabel(c1);
  quit.setColorForeground(c);
  quit.setColorBackground(c);
  quit.setColorActive(c);
  quit.getCaptionLabel().setSize(72);
  quit.getCaptionLabel().alignX(ControlP5.LEFT);
  // When hovering...
  quit.onEnter(new CallbackListener() { public void controlEvent(CallbackEvent theEvent) {
    quit.setColorLabel(0xff9c5b30);
  } } );
  // When leaving button...
  quit.onLeave(new CallbackListener() { public void controlEvent(CallbackEvent theEvent) {
    quit.setColorLabel(color(250));
  } } );
  // When clicked... close the program
  quit.onClick(new CallbackListener() { public void controlEvent(CallbackEvent theEvent) {
    exit();
  } } );
  
  // Restart button
  restart = controlP5.addButton("Restart", 0, 200, 372 + 20 + 72, 345, 70);
  restart.getCaptionLabel().setFont(font);
  restart.setColorLabel(c1);
  restart.setColorForeground(c);
  restart.setColorBackground(c);
  restart.setColorActive(c);
  restart.getCaptionLabel().setSize(72);
  restart.getCaptionLabel().alignX(ControlP5.LEFT);
  // When hovering...
  restart.onEnter(new CallbackListener() { public void controlEvent(CallbackEvent theEvent) {
    restart.setColorLabel(0xff9c5b30);
  } } );
  // When leaving button...
  restart.onLeave(new CallbackListener() { public void controlEvent(CallbackEvent theEvent) {
    restart.setColorLabel(color(250));
  } } );
  // When clicked... restart the game
  restart.onClick(new CallbackListener() { public void controlEvent(CallbackEvent theEvent) {
    restart.setColorLabel(color(250));
    handleRestart();
    prevState = PAUSE;
  } } );
  restart.hide();  // Hide initially as it is only displayed on the pause/lose/win screen
  
  // Restart level button
  restartLevel = controlP5.addButton("Restart From Checkpoint", 0, 200, 372 + 40 + 72 + 72, 1111, 70);
  restartLevel.getCaptionLabel().setFont(font);
  restartLevel.setColorLabel(c1);
  restartLevel.setColorForeground(c);
  restartLevel.setColorBackground(c); 
  restartLevel.setColorActive(c);
  restartLevel.getCaptionLabel().setSize(72);
  restartLevel.getCaptionLabel().alignX(ControlP5.LEFT);
  // When hovering...
  restartLevel.onEnter(new CallbackListener() { public void controlEvent(CallbackEvent theEvent) {
    restartLevel.setColorLabel(0xff9c5b30);
  } } );
  // When leaving button...
  restartLevel.onLeave(new CallbackListener() { public void controlEvent(CallbackEvent theEvent) {
    restartLevel.setColorLabel(color(250));
  } } );
  // When clicked...restart the level
  restartLevel.onClick(new CallbackListener() { public void controlEvent(CallbackEvent theEvent) {
    restartLevel.setColorLabel(color(250));
    handleRestartLevel();
    prevState = LOST;
  } } );
  restartLevel.hide();  // Hide initially as it is only displayed on the lose screen
  
  // Go to start button (basically restart)
  menu = controlP5.addButton("Menu", 0, 200, 372 + 10, 195, 70);
  menu.getCaptionLabel().setFont(font);
  menu.setColorLabel(c1);
  menu.setColorForeground(c);
  menu.setColorBackground(c);
  menu.setColorActive(c);
  menu.getCaptionLabel().setSize(72);
  menu.getCaptionLabel().alignX(ControlP5.LEFT);
  // When hovering...
  menu.onEnter(new CallbackListener() { public void controlEvent(CallbackEvent theEvent) {
    menu.setColorLabel(0xff9c5b30);
  } } );
  // When leaving button...
  menu.onLeave(new CallbackListener() { public void controlEvent(CallbackEvent theEvent) {
    menu.setColorLabel(color(250));
  } } );
  // When clicked... go the start screen (reset game, different name);
  menu.onClick(new CallbackListener() { public void controlEvent(CallbackEvent theEvent) {
    menu.setColorLabel(color(250));
    handleRestart();
    prevState = PAUSE;
  } } );
  menu.hide();  // Hide initially as it is only displayed on the win screen
  
  // Controls button
  controls = controlP5.addButton("Controls", 0, 200, 372 + 10, 420, 70);
  controls.getCaptionLabel().setFont(font);               
  controls.setColorLabel(c1);   
  controls.setColorForeground(c);         
  controls.setColorBackground(c);       
  controls.setColorActive(c);
  controls.getCaptionLabel().setSize(72);
  controls.getCaptionLabel().alignX(ControlP5.LEFT);
  // When hovering...
  controls.onEnter(new CallbackListener() { public void controlEvent(CallbackEvent theEvent) {
    controls.setColorLabel(0xff9c5b30);
  } } );
  // When leaving button... set secondary color if enabled 
  controls.onLeave(new CallbackListener() { public void controlEvent(CallbackEvent theEvent) {
    if(showControls)
      controls.setColorLabel(0xffC16F3C);
    else
      controls.setColorLabel(color(250));
  } } );
  // When clicked... toggle viewing the controls
  controls.onClick(new CallbackListener() { public void controlEvent(CallbackEvent theEvent) {
    showControls =! showControls;
  } } );
  
  // Resume button
  resume = controlP5.addButton("Resume", 0, 200, 300, 335, 70);
  resume.getCaptionLabel().setFont(font);               
  resume.setColorLabel(c1);   
  resume.setColorForeground(c);         
  resume.setColorBackground(c);        
  resume.setColorActive(c);
  resume.getCaptionLabel().setSize(72);
  resume.getCaptionLabel().alignX(ControlP5.LEFT);
  // When hovering...
  resume.onEnter(new CallbackListener() { public void controlEvent(CallbackEvent theEvent) {
    resume.setColorLabel(0xff9c5b30);
  } } );
  // When leaving button...
  resume.onLeave(new CallbackListener() { public void controlEvent(CallbackEvent theEvent) {
    resume.setColorLabel(color(250));
  } } );
  // When clicked... Resume game
  resume.onClick(new CallbackListener() { public void controlEvent(CallbackEvent theEvent) {
    handleUnpause();
  } } );
  resume.hide();  // Hide initially as it is only displayed on the pause screen
  println("MESSAGE: Button initialization successful.");
}

// Load sequential sprites into given array by their name
public void loadSpriteFrames(PImage[] array, String name) {
  for(int i = 0; i < array.length; i++)
      array[i] = loadImage(name + i + ".png");
}

// Load sequential sounds into given array by their name
public void loadSounds(AudioPlayer[] array, String name) {
  for(int i = 0; i < array.length; i++)
      array[i] = minim.loadFile(name + i + ".wav");
}
// Render all entities
public void renderEntities() {
  // Render player
  player.renderSprite();
  
  // Render enemies and their projectiles
  for (int i = 0; i < enemies.size(); i++) {
    Enemy e = enemies.get(i);
    e.renderSprite();
    e.renderPlasma();
  }
  
  // Render player's projectiles + aim trajectory 
  player.renderArrows();
  if(shoot && player.shootCooldown <= 0 && trajectory)
    player.renderArrowTrajectory(player.arrowPos, player.arrowVel, player.timerArrowVel);
}

// Render interactables (portals, camp, gems, etc.)
public void renderForeground() {
  for(int i = 0; i < interactables.size(); i++) {
    Interactable obj = interactables.get(i);
    obj.renderSprite();
  }
}

// Render backgrond image
public void renderBackground() {
  background(220, 60);  // Solid color behind
  imageMode(CORNERS);
  pushMatrix();
  // Stop scrolling if near canvas edge
  if(!player.nearWall)
    offset -= player.vel.x * bgSpeed;
  translate(offset, 0);
  tint(255, 60);
  image(currBG, -bgWidth, 0);  // Render background on either side as well
  tint(255, 60);
  image(currBG, 0, 0);
  tint(255, 60);
  image(currBG, bgWidth, 0);  // Render background on either side as well
  popMatrix();
  if(offset <= -bgWidth || offset >= bgWidth)  // Can't remember
    offset = 0;
}

public void renderUI() {
  // DECOMISSIONED - See main tab controls
  //if (inventory)
  //  player.renderInventory();
  
  // Render HUD (health bar)
  if(!paused)  
    ui.renderHUD();
}

// Play sounds
public void playSound(AudioPlayer sound) {
  sound.play(0);
}
// --- Constants --- //
// Key Codes for each key
final int leftKey = 65;           // A
final int rightKey = 68;          // D
final int jumpKey = 32;           // Space
final int runKey = 16;            // Shift
final int shootKey = LEFT;        // Left Mouse Button
final int interactKey = 69;       // E
final int trajectoryKey = RIGHT;  // Right Mouse Button
//final int inventoryKey = 9;       // Tab (decomissioned)
final int pauseKey = 27;          // Esc

// --- Variables --- //
boolean left, right, jump, run, shoot, interact, trajectory, inventory, paused;  // Pressed key
boolean interactKeyHeldDown, inventoryKeyHeldDown, pauseKeyHeldDown;             // Key held down

// --- Methods --- //
public void keyPressed() {
  //println(keyCode);
  if(!paused) {  // Ensure no gameplay button is pressed when paused
    if (keyCode == leftKey)
      left = true;
    if (keyCode == rightKey)
      right = true;
    if (keyCode == jumpKey)
      jump = true;
    if (keyCode == runKey)
      run = true;
    if (keyCode == interactKey)
        interact = true;
    //if (keyCode == inventoryKey) {
    //  if (!inventoryKeyHeldDown) {
    //    inventory =! inventory;
    //    if (inventory)
    //      println("UI: Showing inventory...");
    //    else
    //      println("UI: Hiding inventory...");
    //  }
    //  inventoryKeyHeldDown = true;
    //}
  }
  // Pause only when in game
  if (keyCode == pauseKey) {
    if (!pauseKeyHeldDown && state != START && state != WON && state != LOST) {
      paused =! paused;
      if (paused) {
        player.vel = new PVector(0, 0);
        prevState = state;
        state = PAUSE;
        println("UI: Pausing game...");
      }
      else {
        handleUnpause();
      }
    }
    pauseKeyHeldDown = true;
    key = 0;  // Override default action of Esc key in Processing (quit program)
  }
}

// Set all keys to false when released
public void keyReleased() {
  if (keyCode == leftKey)
    left = false;
  if (keyCode == rightKey)
    right = false;
  if (keyCode == jumpKey)
    jump = false;
  if (keyCode == runKey)
    run = false;
  if (keyCode == interactKey) {
    switching = false;
    interact = false;
  }
  //if (keyCode == inventoryKey)
  //  inventoryKeyHeldDown = false;
  if (keyCode == pauseKey)
    pauseKeyHeldDown = false;
}

// Draw bow
public void mousePressed() {
  if (mouseButton == shootKey && !paused && state == GAMEPLAY && player.shootCooldown <= 0)
    shoot = true;
}

// Shoot arrow and toggle arrow trajectory arc
public void mouseReleased() {
  if (mouseButton == shootKey && !paused && state == GAMEPLAY) {
    player.shoot();  // Finally shoot the arrow
    shoot = false;
  }
  if (mouseButton == trajectoryKey && !paused && state == GAMEPLAY)
    trajectory =! trajectory;
}
// --- Constants --- //
// Standard levels for substates of gameplay and narrative 
final int LVL_1 = 0;
final int LVL_2 = 1;
final int LVL_3 = 2;
final int LVL_4 = 3;
final int LVL_5 = 4;
final int LVL_6 = 5;
final int LVL_7 = 6;
final int LVL_8 = 7;
final int LVL_9 = 8;
final int LVL_10 = 9;

// --- Variables --- //
boolean switching;  // Switching narrative level
int narrTimer = 0;  // Timer to ensure player doesn't spam through the dialogue

// Default states
int level = LVL_1;
int narrOneLevel = LVL_1;
int narrTwoLevel = LVL_1;
int narrThreeLevel = LVL_1;
int narrFourLevel = LVL_1;
int gameOneLevel = LVL_1;
int gameTwoLevel = LVL_1;
int gameThreeLevel = LVL_1;
int gameFourLevel = LVL_1;

// Characters
String strNarr = "Narrator";
String strInfo = "Note";
String strPlayer = "Alcinous";
String strEnemy = "Enemy";
String strBoss = "Invisible Boss";

// Dialogue - Level One
String narrOneLevelOne = "Deep in the woods of Esqueria, Alcinous delivers\nan urgent message to the nearby village of Polt.";
String narrOneLevelTwo = "The message urges the village to prepare\nfor an incoming invasion from unknown forces.";
String narrOneLevelThree = "Press E while you hover over the tent to\nsleep and tend to your wounds.";
String narrOneLevelFour = "Where did the village go???\nPolt is supposed to be right here!";
String narrOneLevelFive = "Those monsters must have had a hand in\nuprooting Polt. I must defeat them\nand save the survivors!";

// Dialogue - Level Two
String narrTwoLevelOne = "What kind of magic is this?\nWhere am I?";
String narrTwoLevelTwo = "Nonetheless, I must trudge forward to\nsave my people.";
String narrTwoLevelThree = "Phew, how many monsters are there?\nCome out evil! I will defeat you all!";
String narrTwoLevelFour = "Ha! In your dreams human!";
String narrTwoLevelFive = "There must be another portal nearby...";

// Dialogue - Level Three
String narrThreeLevelOne = "Who dares enter my realm???";
String narrThreeLevelTwo = "You shall pay for disturbing me!\nMinions, ATTACK!";
String narrThreeLevelThree = "ARGH! YOU LITTLE BRAT, COME HERE!";
String narrThreeLevelFour = "NOW DIE!!!";
String narrThreeLevelFive = "The people of Polt are free!\nAll thanks to you :>";

// Dialogue Box Variables
int narrPadding;
int narrAlpha;
PVector narrPos;
PVector narrDim;

// Switch between losing and winning each level
public void handleSwitches() {
  if(hasLost())
    startLose();
    
  if (hasWon())
    if(level == LVL_3)  // Check if on last level
      startWin();
    else {
      level++;  // Go to next level
      handleLevelChange();
    }
}

// Gameplay states for each level
public void handleGameplaySwitches() {
  switch(level) {
    case(LVL_1):
      handleLevelOneGameplaySwitches();
      break;
    case(LVL_2):
      handleLevelTwoGameplaySwitches();
      break;
    case(LVL_3):
      handleLevelThreeGameplaySwitches();
      break;
  }
  handleLowestLevelSwitches();  // Event Triggers 
  //println(enemies.size());
  //println("Gameplay: " + gameThreeLevel);
  //println("Narration: " + narrThreeLevel);
}

// Narrative states for each level
public void handleNarrativeSwitches() {
  switch(level) {
    case(LVL_1):
      handleLevelOneNarrativeSwitches();
      break;
    case(LVL_2):
      handleLevelTwoNarrativeSwitches();
      break;
    case(LVL_3):
      handleLevelThreeNarrativeSwitches();
      break;
  }
  // Show interaction disabled for first second of dialogue appearing
  if(narrTimer < 60) {
    narrTimer++;
    ui.showKeyE(20);
  }
  else
    ui.showKeyE(60);
  handleLowestLevelSwitches();
  //println(enemies.size());
  //println("Gameplay: " + gameThreeLevel);
  //println("Narration: " + narrThreeLevel);
}

// Level One narration
public void handleLevelOneNarrativeSwitches() {
  switch(narrOneLevel) {
    case(LVL_1):
      ui.renderNarrative(strNarr, narrOneLevelOne, narrPos, narrDim, narrPadding, narrAlpha);
      break;
    case(LVL_2):
      ui.renderNarrative(strNarr, narrOneLevelTwo, narrPos, narrDim, narrPadding, narrAlpha);
      break;
    case(LVL_3):
      ui.renderNarrative(strInfo, narrOneLevelThree, narrPos, narrDim, narrPadding, narrAlpha);
      break;
    case(LVL_4):
      ui.renderNarrative(strPlayer, narrOneLevelFour, narrPos, narrDim, narrPadding, narrAlpha);
      break;
    case(LVL_5):
      ui.renderNarrative(strPlayer, narrOneLevelFive, narrPos, narrDim, narrPadding, narrAlpha);
      break;
    case(LVL_6):
      break;
  }
}

// Level Two narration
public void handleLevelTwoNarrativeSwitches() {
  switch(narrTwoLevel) {
    case(LVL_1):
      ui.renderNarrative(strPlayer, narrTwoLevelOne, narrPos, narrDim, narrPadding, narrAlpha);
      break;
    case(LVL_2):
      ui.renderNarrative(strPlayer, narrTwoLevelTwo, narrPos, narrDim, narrPadding, narrAlpha);
      break;
    case(LVL_3):
      ui.renderNarrative(strPlayer, narrTwoLevelThree, narrPos, narrDim, narrPadding, narrAlpha);
      break;
    case(LVL_4):
      ui.renderNarrative(strEnemy, narrTwoLevelFour, narrPos, narrDim, narrPadding, narrAlpha);
      break;
    case(LVL_5):
      ui.renderNarrative(strPlayer, narrTwoLevelFive, narrPos, narrDim, narrPadding, narrAlpha);
      break;
  }
}

// Level Three narration
public void handleLevelThreeNarrativeSwitches() {
  player.vel = new PVector(0, 0);
  switch(narrThreeLevel) {
    case(LVL_1):
      ui.renderNarrative(strBoss, narrThreeLevelOne, narrPos, narrDim, narrPadding, narrAlpha);
      break;
    case(LVL_2):
      ui.renderNarrative(strBoss, narrThreeLevelTwo, narrPos, narrDim, narrPadding, narrAlpha);
      break;
    case(LVL_3):
      ui.renderNarrative(strBoss, narrThreeLevelThree, narrPos, narrDim, narrPadding, narrAlpha);
      break;
    case(LVL_4):
      ui.renderNarrative(strBoss, narrThreeLevelFour, narrPos, narrDim, narrPadding, narrAlpha);
      break;
    case(LVL_5):
      if(state != WON)
        ui.renderNarrative(strNarr, narrThreeLevelFive, narrPos, narrDim, narrPadding, narrAlpha);
      break;
    case(LVL_6):
      break;
  }
}

// Level One gameplay
public void handleLevelOneGameplaySwitches() {
  switch(gameOneLevel) {
    case(LVL_1):
      break;
    case(LVL_2):
      break;
    case(LVL_3):
      break;
    case(LVL_4):
      break;
    case(LVL_5):
      break;
    case(LVL_6):
      break;
  }
}

// Level Two gameplay
public void handleLevelTwoGameplaySwitches() {
  switch(gameTwoLevel) {
    case(LVL_1):
      break;
    case(LVL_2):
      break;
    case(LVL_3):
      break;
    case(LVL_4):
      break;
  }
}

// Level Three gameplay
public void handleLevelThreeGameplaySwitches() {
  switch(gameThreeLevel) {
    case(LVL_1):
      break;
    case(LVL_2):
      break;
    case(LVL_3):
      break;
    case(LVL_4):
      break;
    case(LVL_5):
      break;
    case(LVL_6):
      break;
  }
}

// Checking if player has reached the end of each level
public boolean hasWon() {
  if(state == GAMEPLAY) {
    if(gameOneLevel == LVL_6) {
      gameOneLevel = LVL_5;
      return true;
    }
    
    if(gameTwoLevel == LVL_6){
      gameTwoLevel = LVL_5;
      return true;
    }
      
    if(gameThreeLevel == LVL_5){
      gameThreeLevel = LVL_4;
      return true;
    }
  }
  return false;
}

// Change state when won
public void startWin() {
  state = WON; 
}

// Check if player has died
public boolean hasLost() {
  return !player.isAlive;
}

// Change state when lost
public void startLose() {
  state = LOST;
}

// Each event that switches narration and gameplay
public void handleLowestLevelSwitches() {
  // Changes to next narration
  if (state == NARRATIVE && interact && !switching && narrTimer >= 60) {
    switch(level) {
      case(LVL_1):
        narrOneLevel++;
        break;
      case(LVL_2):
        narrTwoLevel++;
        break;
      case(LVL_3):
        narrThreeLevel++;
        break;
    }
    
    switching = true;  // Ensure this happens only once
    narrTimer = 0;  // Reset dialogue timer
    
    // Level One narrative-to-gameplay switches
    if(level == LVL_1 && (narrOneLevel == LVL_3 || narrOneLevel == LVL_4 || narrOneLevel == LVL_5 || narrOneLevel == LVL_6)) {
      state = GAMEPLAY;    
      if(narrOneLevel == LVL_5) {
        initEnemies(3, new PVector(0, width));
      }
    }
    
    // Level Two narrative-to-gameplay switches
    if(level == LVL_2 && (narrTwoLevel == LVL_3 || narrTwoLevel == LVL_4 || narrTwoLevel == LVL_5 || narrTwoLevel == LVL_6)) {
      state = GAMEPLAY;
      if(narrTwoLevel == LVL_3)
        initEnemies(4, new PVector(width/2, width));
      if(narrTwoLevel == LVL_4)
        initEnemies(5, new PVector(width * 2, width * 3));
    }
    
    // Level Three narrative-to-gameplay switches
    if(level == LVL_3 && (narrThreeLevel == LVL_3 || narrThreeLevel == LVL_5 || narrThreeLevel == LVL_6)) {
      state = GAMEPLAY;
      if(narrThreeLevel == LVL_3)
        initEnemies(5, new PVector(width/2, width * 1.5f));
      if(narrThreeLevel == LVL_5)
        initEnemies(7, new PVector(-width, width * 2));
    }
  }
  
  // Level One gameplay-to-narrative switches
  if (state == GAMEPLAY && level == LVL_1) {
    if(!player.nearWall && gameOneLevel == LVL_1) // Leaves wall
      switchToNarr();
    
    if(interactables.get(0).pos.x <= player.pos.x && gameOneLevel == LVL_2)  // Approaches camp
      switchToNarr();
    
    if(player.pos.x >= width/1.5f && gameOneLevel == LVL_3)  // Near "town"
      switchToNarr();
    
    if(gameOneLevel == LVL_4 && player.getGemCount() >= 1)  // Obtains gem
          switchToNarr();
    
    if(gameOneLevel == LVL_5 && interactables.get(1).isClicked())  // Enters green portal
      gameOneLevel++;
  }
  
  // Level Two gameplay-to-narrative switches
  if (state == GAMEPLAY && level == LVL_2) {
    if(!player.nearWall && gameTwoLevel == LVL_1)  // Leaves wall
      switchToNarr();
    
    if(gameTwoLevel == LVL_2 && player.getGemCount() >= 2 && enemies.size() == 0)  // Kills enemies and obtains 2nd gem
      switchToNarr();
    
    if(gameTwoLevel == LVL_3 && enemies.size() > 0)  // Loads enemies after enemy dialogue
      switchToNarr();
    
    if(gameTwoLevel == LVL_4 && player.getGemCount() >= 3 && enemies.size() == 0)  // Kills enemies and obtains 3rd gem
      switchToNarr();
    
    if(gameTwoLevel == LVL_5 && interactables.get(2).isClicked())  // Enters blue portal
      gameTwoLevel++;
  }
  
  // Level Three gameplay-to-narrative switches
  if (state == GAMEPLAY && level == LVL_3) {
    if(!player.nearWall && gameThreeLevel == LVL_1)  // Leaves wall
      switchToNarr();
    
    if(gameThreeLevel == LVL_2 && enemies.size() == 0) {  // Kill enemies
      // Invisible boss forces player into the center of the map
      if(player.pos.x < width/2 - 5)
        player.accl(new PVector(1, 0));
      else if(player.pos.x > width/2 + 5)
        player.accl(new PVector(-1, 0));
      else {
        switchToNarr();
      }
    }
    
    if(gameThreeLevel == LVL_3 && enemies.size() == 0 && narrThreeLevel == LVL_5 )  // Kills enemies
      switchToNarr();
    
    if(gameThreeLevel == LVL_4 && narrThreeLevel == LVL_6)  // Finish narration
      gameThreeLevel++;
  }
}

// Switches to narration
public void switchToNarr() {
  state = NARRATIVE;
  // Changes to next gameplay
  switch(level) {
      case(LVL_1):
        gameOneLevel++;
        break;
      case(LVL_2):
        gameTwoLevel++;
        break;
      case(LVL_3):
        gameThreeLevel++;
        break;
    }
  player.vel = new PVector(0, 0);
}

// Switching between levels One, Two, Three
public void handleLevelChange() {
  currBG = spritesEnviro[level];  // Change background
  player.arrows.clear();  // Clean the field
  
  if(level == LVL_1) {  // Shouldn't happen
    groundLevel = 113;
    interactables.get(1).pos.x = 0;
    player.pos.x = 1375;
  }
  if(level == LVL_2) {  // Add blue portal, shifts player and portal around 
    groundLevel = 83;
    player.pos.x = 200;
    interactables.get(1).pos = new PVector(player.pos.x, height - groundLevel - interactables.get(1).sprite.height/2);  // Green portal 
    interactables.get(0).pos = new PVector(width, height - groundLevel + 7 - interactables.get(0).sprite.height/2);  // Camp
    PVector levelTwoPortalPos = new PVector(5250, height - groundLevel - sprPortalBlueFrame[0].height/2);
    PVector levelTwoPortalDim = new PVector(256, 256);
    interactables.add(new Portal(levelTwoPortalPos, levelTwoPortalDim, sprPortalBlueFrame, sprPortalBlueOpen, sprPortalBlueIdle));  // Blue portal
  }
  if(level == LVL_3) {  // Shifts player and portals around
    groundLevel = 145;
    player.pos.x = 200;
    interactables.get(1).pos = new PVector(width/2, -5000);  // Ensure you can't see green portal
    interactables.get(0).pos = new PVector(width, height - groundLevel + 7 - interactables.get(0).sprite.height/2);  // Camp
    interactables.get(2).pos = new PVector(player.pos.x, height - groundLevel - interactables.get(2).sprite.height/2);  // Blue portal
  }
}
/* 
Arrow Class

Mainly for use by the player to shoot arrows at enemies.
Used in an arrayList.
Handles rendering, dying, and gravity movement. 
Other things are handled by the Projectile superclass.
*/ 

class Arrow extends Projectile {
  
  // PVector: Dimensions of arrow sprite
  // PVector[]: Bounding box of arrow 
  Arrow(PVector pos, PVector vel, int dmg, float rot) {
    super(pos, vel, dmg, rot, new PVector(10, 38), new PVector[]{new PVector(10, 38), new PVector(0,0)});
  }
  
  // Render arrow sprite
  public void renderSprite() {
    pushMatrix();
    translate(pos.x, pos.y);
    handleSpriteStates();
    tint(255, alpha);
    image(sprArrow[0], 0, 0);
    popMatrix();
  }
  
  // Scale and rotate sprite
  public void handleSpriteStates() {
    if(!grounded)
      rot = calcRot() + radians(90);
    rotate(rot);
    if(isSpriteFlipped())
      scale(-1, 1);
  }
  
  // Fade arrow out when it dies
  public void handleDeath() {
    if(!isAlive && dying) {
      if(dyingTimer > 0)
        dyingTimer--;
      if(dyingTimer <= 60 && dyingTimer >= 0)  // Fade arrow out for a second
        alpha--;
    }
    else if(!isAlive && !dying) {  // Start dying process
      dyingTimer += 600;
      dying = true;
      println("ENTITY: Arrow is dying...");
    }
  }
  
  // Check if arrow hit the floor
  public void handleFloor() {
    if (grounded && isAlive) {
      vel.y = 0;
      vel.x = 0;
      this.pos.y = height - dim.y/2 + 4 - groundLevel;
      int sound = PApplet.parseInt(random(4, 9));  // Random sound for hitting floor
      playSound(sfxShoot[sound]);
      isAlive = false;
    }
    else if(isAlive)
      accl(acclGravity);  // Add gravity to arrow
  }
}
/* 
Character Class

The class that the player is made from.
Character can:
  Move with the use of controls
  Shoot arrows using arrayList
  Pickup items
  Interact with interactables  
*/ 

class Char extends MovingObject {

  // -- Constants -- //
  // Accelerations
  final PVector acclJump = new PVector(0, -20);
  final PVector acclLunge = new PVector(2.5f, -15);
  final PVector acclGravity = new PVector(0, 1);
  final PVector acclLeft = new PVector(-0.25f, 0);
  final PVector acclRight = new PVector(0.25f, 0);

  // Sprite Constants
  final int IDLE = 0;
  final int WALK = 1;
  final int RUN = 2;
  final int JUMP = 3;
  final int DASH = 4;
  final int ATTACK1 = 5;
  final int ATTACK2 = 6;
  
  final int shootCooldownMax = 20;

  // -- Variables -- //
  PVector health, maxHealth; // x = health | y = shield (regenerative health while not in combat)
  
  // Movement and timers
  boolean touchingWall, nearWall;
  float movementDamp = 0.75f;
  int jumpCount = 0;
  int timerArrowVel = 0;
  int shootCooldown = 0;
  int dyingTimer;
  float dmgdTimer;
  
  // Arrows and other entities
  float angleBtwnMouse;
  boolean aiming;  // Is the character drawing the bow?
  PVector arrowPos, arrowVel;
  ArrayList<Arrow> arrows = new ArrayList<Arrow>();   // Arrows
  ArrayList<Item> inventory = new ArrayList<Item>();  // Items (gems)
  
  // Sprites and animations
  PImage spriteCurrent;
  int spriteState;
  int spriteStatePrev;
  PImage[] activeFrames;
  int currFrame = 0;
  int animationRate = 90;
  boolean spriteFlipped;
  
  // Sounds
  boolean walking, running, jumping, doubleJumping;  // Handles sounds when doing these things
  
  // -- Constructor -- //
  Char(PVector pos, PVector vel, PVector dim, PVector[] bb, PVector health, PVector maxHealth) {
    super(pos, vel, dim, bb);
    this.maxHealth = maxHealth;
    this.health = health;
    this.activeFrames = sprCharIdle;
    this.spriteCurrent = sprCharIdle[0];
    this.isAlive = true;
    this.alpha = 60;
  }
  
  // -- Methods -- //
  // Handles controls, health, death, and arrows on top of MovingObject 
  public void update() {
    super.update();
    if(isAlive) {
      handleControls();
      handleArrows();
      handleHealth();
    }
    else
      handleDeath();
  }
  
  // Calculate movement of character
  public void move() {
    super.move();
    vel.x *= movementDamp;
    vel.y = constrain(vel.y, -20, 60);
    handleWalls();
    handleGravity();
  }
  
  //  Checks for walls and corrects movement when near them
  public void handleWalls() {
    touchingWall = false;
    nearWall = false;
    
    // Check for right wall
    if(pos.x + dim.x/2 > width) {
      pos.x = width - dim.y/2;  // Corrects character location
      touchingWall = true;
    }
    // Check for left wall
    if(pos.x - dim.x/2 < 0) {
      pos.x = dim.y/2;
      touchingWall = true;
    }
    
    // Ensure natural movement when background is not scrolling
    // Right wall
    if(pos.x + dim.x/2 > width - 400) {
      if(left) {
        PVector acclRunLeft = acclLeft.copy().mult(bgSpeed);
        accl(acclRunLeft);
      }
      if(right) {
        PVector acclRunRight = acclRight.copy().mult(bgSpeed);
        accl(acclRunRight);
      }
      nearWall = true; 
    }
    // Left wall
    if(pos.x - dim.x/2 < 400) {
      if(left) {
        PVector acclRunLeft = acclLeft.copy().mult(bgSpeed);
        accl(acclRunLeft);
      }
      if(right) {
        PVector acclRunRight = acclRight.copy().mult(bgSpeed);
        accl(acclRunRight);
      }
      nearWall = true;
    }
  }
  
  // Translate controls to actions
  public void handleControls() {
    if (mousePressed && mouseButton == shootKey && !paused && state == GAMEPLAY && player.shootCooldown <= 0)  // Draw bow while holding down button constantly
      shoot = true;
    if (left)  // M<ove left
      accl(acclLeft);
    if (right)  // Move right
      accl(acclRight);
    if (jump && grounded || jump && jumpCount < 2  && !grounded)  // Single jump or double jump/lunge
      jump();
    if (grounded)  // Reset jump
      jumpCount = 0;
    if (left && run || right && run)  // Move faster
      run();
    if (shoot && shootCooldown <= 0)  // Draw bow and shoot arrow
      shoot();
    if (interact)  // Interact with interactables
      interact();
  }
  
  // Play walking and running sounds
  public void handleSounds() {
    if(isAlive && !paused) {  // Only play when alive and not paused
    if((left || right) && (!walking || !running) && grounded) {
      if(run) {  // When running
        sfxChar[1].play();
        sfxChar[0].pause();
        walking = false;
        running = true;
      }
      else {  // When walking
        sfxChar[0].play();
        sfxChar[1].pause();
        running = false;
        walking = true;
      }
    }
    else if((!left && !right) || !grounded) {  // When idle
      walking = false;
      running = false;
      sfxChar[0].pause();
      sfxChar[1].pause();
    }

    // Loop sounds manually
    if(sfxChar[0].position() == sfxChar[0].length())
      sfxChar[0].rewind();
    if(sfxChar[1].position() == sfxChar[1].length())
      sfxChar[1].rewind();
    }
    else {  // Stop sounds when paused or dead
      sfxChar[0].pause();
      sfxChar[1].pause();
    }
  }

  // Jump!
  public void jump() {
    grounded = false;
    jump = false;  // Only jump once
    jumpCount++;
    
    // Jump regularly first
    if (jumpCount == 1) {
      println("PLAYER ACTION: Jumping...");
      accl(acclJump);
      playSound(sfxChar[2]);  // Jump sound could be better :/
    }
    // Either jump again or lunge in a certain direction when double jumping
    else if (jumpCount == 2) {
      println("PLAYER ACTION: Double jumping...");
      PVector acclLungeTemp = acclLunge.copy();
      if(vel.y < 0)   // Still jumping
        acclLungeTemp.x *= 0.25f;
      if(vel.y > 0)   // Falling + below
        acclLungeTemp.x *= 2;
      if(vel.y > 15)  // Falling fast
        acclLungeTemp.y *= 2;
      else if(vel.y > 10)  // Falling medium-fast
        acclLungeTemp.y *= 1.75f;
      else if(vel.y > 5)   // Falling light
        acclLungeTemp.y *= 1.25f;
      if(right)  // If moving right, lunge right
        accl(acclLungeTemp);
      else if(left) {  // If moving left, lunge left
        PVector acclLungeLeft = acclLungeTemp.copy();
        acclLungeLeft.x *= -1;
        accl(acclLungeLeft);
      }
      else {  // If not moving, jump up only
        PVector acclLungeUp = acclLungeTemp.copy();
        acclLungeUp.x = 0;
        accl(acclLungeUp);
      }
      playSound(sfxChar[3]);  // Jump sound could be better :/
    }
  }

  // Increase speed when runnning (doubled) 
  public void run() {
    if(left) {
      PVector acclRunLeft = acclLeft.copy().mult(1);
      accl(acclRunLeft);
    }
    if(right) {
      PVector acclRunRight = acclRight.copy().mult(1);
      accl(acclRunRight);
    }
  }

  // Draw bow and shoot arrows
  public void shoot() {
    PVector mouse;
    int arrowDmg = 1;
    float arrowRot;
    if(mousePressed)
      aiming = true;
    
    // When aiming, calculate arrow trajectory
    if (aiming) {
      if (timerArrowVel <= 1 && shoot) {  // At the start of drawing the bow
        println("PLAYER ACTION: Aiming arrow...");
        playSound(sfxShoot[0]);  // Drawing bow sound 
      }
      
      // Math
      arrowPos = new PVector(this.pos.x, this.pos.y);  // Initial position of arrow
      mouse = new PVector(mouseX, mouseY);
      float angle = angleBetween(pos, mouse) - PI;  // Initial angle of arrow
      arrowVel = PVector.fromAngle(angle);
      arrowVel.normalize();
      float arrowVelMult = map(timerArrowVel, 0, 60, 10, 75) / 2;  
      arrowVel.mult(arrowVelMult);  // Velocity of arrow
      arrowRot = degrees(angle);    // Calculating sprite rotation
      timerArrowVel++;
      if ((timerArrowVel > 60 || (!mousePressed && timerArrowVel > 1)) && shootCooldown <= 0) {  // Finally shoot arrow
        println("PLAYER ACTION: Shooting arrow...");
        arrows.add(new Arrow(arrowPos, arrowVel, arrowDmg, arrowRot));
        playSound(sfxShoot[1]);  // Arrow shooting sound
        sfxShoot[0].pause();  // Stop drawing bow sound
        shoot = false;
        timerArrowVel = 0;
        shootCooldown = shootCooldownMax;  // Put bow on cooldown (turn red)
      }
    }
  }
  
  // Update arrows movement
  public void handleArrows() {
    if(shootCooldown > 0)  // Decrease bow cooldown
      shootCooldown--;
    for (int i = 0; i < arrows.size(); i++) {
      Arrow a = arrows.get(i);
      a.update();
        for(int j = 0; j < enemies.size(); j++) {
          Enemy e = enemies.get(j);
          if(a.isHit(e) && e.isAlive && a.isAlive) {  // If arrow hits an enemy, kill arrow and deal damage
            println("PLAYER ACTION: Arrow hit enemy.");            
            e.decHP(a.dmg);
            if(e.health.x == 0)  // Different sound when killing enemy
              playSound(sfxShoot[3]);
            else
              playSound(sfxShoot[2]);
            a.vel = new PVector(0, 0);
            a.dyingTimer += 600;
            a.isAlive = false;
          }
          if(a.isHit(e) && e.isAlive && !a.isAlive) {  // Latch arrow onto enemy (not the best implementation)
            a.pos.add(e.vel);
          }
          if(a.isHit(e) && !e.isAlive && !a.isAlive && !e.dying) {  // Remove arrow quicker when enemy is dead
            a.dyingTimer = 120;
          }
          if(a.isHit(e) && !e.isAlive && !a.isAlive && e.dying && e.currFrame > 3) {  // Arrows fall off of enemy when enemy dies
            a.accl(acclGravity);
          }
        }
      if(!a.isAlive && a.dyingTimer == 0) {  // Remove arrow when it is time... D:
        arrows.remove(a);
        println("ENTITY: Arrow died.");
      }
    }
  }
  
  // Render player's arrows
  public void renderArrows() {
   for (int i = 0; i < arrows.size(); i++)
      arrows.get(i).renderSprite();
  }

  // Handle interactions with interactable objects
  public void interact() {
    for(int i = 0; i < interactables.size(); i++) {
      Interactable obj = interactables.get(i);
      obj.isNear(player, obj.range);
    }
  }

  // Create arrow trajectory arc for helping with aiming
  public void renderArrowTrajectory(PVector pos, PVector vel, float timerArrowVel) {
    float resolution = 2;
    PVector arrowPos, arrowVel;
    arrowPos = pos;
    arrowVel = vel;
    
    while(arrowPos.y < height - groundLevel * 1.5f) {
      for(int i = 0; i < resolution; i++) {
        arrowPos.add(arrowVel);
        arrowVel.add(acclGravity);
      }
      pushMatrix();
      translate(arrowPos.x, arrowPos.y);
      int red = PApplet.parseInt(map(timerArrowVel, 0, 60, 0, 255));
      int green = PApplet.parseInt(map(timerArrowVel, 0, 60, 255, 0));
      fill(red, green, 0);
      noStroke();
      circle(0, 0, 10);
      popMatrix();
    }
  }
  
  // Render the inventory - DECOMMISSIONED
  //void renderInventory() {
  //  pushMatrix();
  //  translate(width/2, height/2);
  //  rectMode(CENTER);
  //  fill(255);
  //  stroke(0);
  //  strokeWeight(5);
  //  rect(0, 0, width/2, height/2);
  //  textAlign(CENTER, CENTER);
  //  textFont(fontItalic);
  //  textSize(48);
  //  fill(0);
  //  text("This is the inventory!", 0, 0);
  //  popMatrix();
  //}

  // Render character's sprite
  public void renderSprite() {
    pushMatrix();
    translate(pos.x, pos.y);
    if(isAlive) {  // Handle animation and scaling
      isSpriteFlipped();
      updateSpriteStates();
    }
    if(spriteFlipped)
      scale(-1, 1);
    tint(255, alpha);
    image(handleSpriteStates(), 0, 0);
    //renderBB();  // To test bounding box around character
    popMatrix();
  }
  
  // Handle animation
  public PImage handleSpriteStates() {
    if (!paused) { // Lock sprite position when paused
      if(frameCount % animationRate == 0) {
        if(currFrame < activeFrames.length-1)
          currFrame++;
        else
          currFrame = 0;
        spriteCurrent = activeFrames[currFrame];
      }
    }
    return spriteCurrent;
  }
  
  // Handle animation states
  public void updateSpriteStates() {
    float angle = angleBtwnMouse();
    dim = new PVector(activeFrames[0].width, activeFrames[0].height);
    // Handle animation states
    if(!paused) { // Lock animation state when paused
      spriteState = IDLE;
      if(left || right)
        if(run)
          spriteState = RUN;
        else
          spriteState = WALK;
      if(!grounded)
        spriteState = JUMP;
      if(shoot && shootCooldown <= 0)
        spriteState = ATTACK1;
      if(shoot && (angle < -30 && angle > -120) && shootCooldown <= 0)
        spriteState = ATTACK2;
    }
    // Handle animation states when changing states
    if(spriteState != spriteStatePrev) {
      switch(spriteState) {
        case(IDLE):
          if(shootCooldown <= 0)
            activeFrames = sprCharIdle;
          else
            activeFrames = sprCharRedIdle;
          animationRate = 90;
          currFrame = 0;
          spriteCurrent = activeFrames[currFrame];
          break;
        case(WALK):
          if(shootCooldown <= 0)
            activeFrames = sprCharMove;
          else
            activeFrames = sprCharRedMove;
          animationRate = 8;
          if(spriteStatePrev != RUN)
            currFrame = 0;
          spriteCurrent = activeFrames[currFrame];
          break;
        case(RUN):
          if(shootCooldown <= 0)
            activeFrames = sprCharMove;
          else
            activeFrames = sprCharRedMove;
          animationRate = 5;
          if(spriteStatePrev != WALK)
            currFrame = 0;
          spriteCurrent = activeFrames[currFrame];
          break;
        case(JUMP):
          if(shootCooldown <= 0)
            activeFrames = sprCharJump;
          else
            activeFrames = sprCharRedJump;
          animationRate = 10;
          currFrame = 0;
          spriteCurrent = activeFrames[currFrame];
          break;
        case(ATTACK1):
          activeFrames = sprCharAtk1;
          animationRate = 8;
          dim = new PVector(activeFrames[0].width, activeFrames[0].height);
          if(spriteStatePrev != ATTACK2)
            currFrame = 0;
          spriteCurrent = activeFrames[currFrame];
          break;
        case(ATTACK2):
          activeFrames = sprCharAtk2;
          animationRate = 8;
          if(spriteStatePrev != ATTACK1)
            currFrame = 0;
          spriteCurrent = activeFrames[currFrame];
          break;        
      }
      spriteStatePrev = spriteState;
    }
    // Handle frame by frame animation states (bounding boxes, bow cooldown, etc)
    switch(spriteState) {
      case(IDLE):
        if(shootCooldown <= 0)
          activeFrames = sprCharIdle;
        else
          activeFrames = sprCharRedIdle;  // Changes bow colour when on bow cooldown
        bb[0] = new PVector(44, 132);
        bb[1] = new PVector(-15, 0);
        break;
      case(WALK):
        if(shootCooldown <= 0)
          activeFrames = sprCharMove;
        else
          activeFrames = sprCharRedMove;
        bb[0] = new PVector(activeFrames[currFrame].width/2, activeFrames[currFrame].height);
        bb[1] = new PVector(5, 0);    
        break;
      case(RUN):
        if(shootCooldown <= 0)
          activeFrames = sprCharMove;
        else
          activeFrames = sprCharRedMove;
        bb[0] = new PVector(activeFrames[currFrame].width/2, activeFrames[currFrame].height);
        bb[1] = new PVector(5, 0);
        break;
      case(JUMP):
        if(shootCooldown <= 0)
          activeFrames = sprCharJump;
        else
          activeFrames = sprCharRedJump;
        bb[0] = new PVector(activeFrames[currFrame].width/2, activeFrames[currFrame].height);
        bb[1] = new PVector(15, 0); 
        break;
      case(ATTACK1):
        bb[0] = new PVector(44, 132);
        bb[1] = new PVector(-15, (activeFrames[currFrame].height - 132) / 2);
        break;
      case(ATTACK2):
        bb[0] = new PVector(44, 132);
        bb[1] = new PVector(-15, (activeFrames[currFrame].height - 132) / 2);
        break;        
    }
  }
  
  // Handle sprite scaling
  public boolean isSpriteFlipped() {
    if(!paused) {
      float angle = angleBtwnMouse();
      if(vel.x > 0)
        spriteFlipped = false;
      if(vel.x < 0)
        spriteFlipped = true;
      if((angle > 90 || angle < -90) && shoot)
        spriteFlipped = false;
      if(angle < 90 && angle > -90 && shoot)
        spriteFlipped = true;
    }
    return spriteFlipped;
  }
  
  // Calculates angle between the mouse and the character's center
  public float angleBtwnMouse() {
    return degrees(angleBetween(pos, new PVector(mouseX, mouseY))) * -1;
  }
  
  // Character gravity
  public void handleGravity() {
    if (grounded) {  // Correct character position when on the ground
      vel.y = 0;
      this.pos.y = height - dim.y/2 - groundLevel; 
    }
    else if(state == GAMEPLAY)
      accl(acclGravity);  // Let the character fall!
  }
  
  // Calculate the health of the character
  public float healthPercentage(boolean accountForShield) {
    if(accountForShield) {
    float totalHealth = health.x + health.y;
    float totalMaxHealth = maxHealth.x + maxHealth.y;
    return totalHealth / totalMaxHealth * 100;
    }
    else
      return health.x / maxHealth.x * 100;
  }

  // Handle health related things
  public void handleHealth() {
    dmgdTimer++;
    // Regen shield when not hit after 6 seconds 
    if (dmgdTimer > 360 && health.y < maxHealth.y && dmgdTimer % 60 == 0)
      health.y += 1;
    if(health.x <= 0)  // Kill character
      isAlive = false;
  }

  // Deal damage to character
  public void decHP(int dmg) { 
    if (health.y - dmg >= 0) {  // Remove shield health first
      health.y -= dmg;
      println(health.y);
    }
    else if (health.y - dmg < 0 && health.y > 0) {  // Remove remaining shield health, then remove regular health
      while (health.y > 0) {
        health.y--;
        dmg--;
      }
      health.x -= dmg;
    }
    else  // Remove regular health
      health.x -= dmg;
    dmgdTimer = 0;  // Reset damaged timer to (shield regen)
  }
  
  // Get the amount of gems in the player's inventory. Useful when character might eventually have other things in their inventory 
  public int getGemCount() {
    int gemCount = 0;
    for (int i = 0; i < inventory.size(); i++) {
      if(inventory.get(i).sprite == sprGem[0]);
        gemCount++;
    }
    return gemCount;
  }
  
  // Fade away when dead...
  public void handleDeath() {
    if(alpha > 0)
      alpha -= 0.33f;
    vel = new PVector(0, 0);
  }
}
/*
Checkpoint Class:

The camp. You can sleep in it when there isn't any monsters around.
Regens your health + shield to full.
Useful midbattle. Can back away to camp to heal.
The one sprite I made from scratch :>
*/

class Checkpoint extends Interactable {
  
  boolean canSleep, isSleeping;
  float alpha = 0;
  float timer = 120;
  
  Checkpoint(PVector pos, PVector dim, PImage sprite, int range) {
    super(pos, dim, sprite, range);
  }
  
  // Check if player is going to sleep
  public void update() {
    super.update();
    if((isClicked() && !interactKeyHeldDown) || isSleeping) {
      handleSleep();
      println("Sleeping...");
    }
    if(isClickedNotNear() && !interactKeyHeldDown)
      println("Cannot sleep. Please come closer to the camp");
  }
  
  // Ensures you can sleep
  public void handleSleep() {
    canSleep = true;
    for(int i = 0; i < enemies.size(); i++) {  // Checks for enemies around the camp
      isNear(enemies.get(i), range * 2);
      if(isNear && !isSleeping) {
        canSleep = false;
        break;
      }
    }
    if(canSleep)
      sleep();
    else
      cannotSleep();
  }
  
  // Handle the actual sleeping process
  public void sleep() {
    isSleeping = true;
    timer--;
    if (isSleeping && alpha <= 60 && timer >= 0) {  // Fade away things
      for (int i = 0; i < enemies.size(); i++)
        enemies.get(i).alpha--;
      player.alpha--;
      alpha++;
    }
    if (timer <= 0) {  // Bring entities back
      for (int i = 0; i < enemies.size(); i++)
        enemies.get(i).alpha += 5;
      player.alpha += 5;
      alpha -= 5;
      timer--;
    }
    if (timer <= 0 && alpha <= 0) {  // After slept
      // Ensure alpha values are reset properly
      alpha = 0;
      timer = 120;
      player.alpha = 60;
      for (int i = 0; i < enemies.size(); i++)
        enemies.get(i).alpha = 60;
      isSleeping = false;
      // Set health, shield to max after slept
      while(player.health.x < player.maxHealth.x)
        player.health.x++;
      while(player.health.y < player.maxHealth.y)
        player.health.y++;
      println("Slept..."); 
    }
  }
  
  // Let player know they cannot sleep
  public void cannotSleep() {
    println("Enemies are nearby... You cannot sleep now");
    // Insert text box that pops up. Did not have time
  }
  
  // Render campground
  public void renderSprite() {
    super.renderSprite();
    pushMatrix();
    translate(width/2, height/2);
    rectMode(CENTER);
    fill(0, alpha);
    noStroke();
    rect(0, 0, width, height);
    popMatrix();
  }
  
  
}
/*
Enemy Class:

Chases character and throws balls of something that deal damage.
This was a pain in the arse to code their projectiles.
But I am proud of the product, if a bit scuffed.
*/

class Enemy extends MovingObject{
  
  // Sprite Constants - Animations
  final int IDLE = 0;
  final int WALK = 1;
  final int ATTACK = 2;
  final int DIE = 3;
  
  PVector health, maxHealth;
  int dmg, dmgTimer, attackRecoverTimer;
  PImage spriteCurrent;
  boolean shooting;
  PVector maxVel;
  ArrayList<Plasma> plasmaBalls = new ArrayList<Plasma>();
  float vel1;
  
  int spriteState;
  int spriteStatePrev;
  
  PImage[] activeFrames;
  int currFrame = 0;
  int animationRate = 90;

  
  Enemy(PVector pos, PVector vel, PVector dim, PVector[] bb, PVector health, int dmg) {
    super(pos, vel, dim, bb);
    this.health = health;
    this.maxHealth = health;
    this.dmg = dmg;
    this.maxVel = vel;
    this.activeFrames = sprWitchIdle;
    this.spriteCurrent = sprWitchIdle[0];
    dmgTimer = PApplet.parseInt(random(30, 120));
  }
  
  // Movement, health, etc.
  public void update() {
    if(isAlive) {
      move();
      grounded();
      handleHealth();
      handleAttack();
    }
    else
      handleDeath();
    handlePlasmas();
  }
  
  // Calc. movement trajectory
  public void move() {
    pos.add(vel);
    vel.x = PVector.fromAngle(angleBetween(player.pos, this.pos)).x;
    vel.x *= 2;
    moveWithChar();
    
    vel.y = constrain(vel.y, -20, 60);
    //handleWalls();  // is free to move around!
    handleGravity();
  }
  
  // Quick dash towards the player
  public void dash() {
    if(dmgTimer > -15) {
    // Need to configure
    float force = PVector.fromAngle(angleBetween(player.pos, this.pos)).x;
    force *= 25;
    println(force);
    accl(new PVector(force, vel.y));
    dmgTimer--;
    }
    else {
      attackRecoverTimer = 60;
      dmgTimer = 120;
    }
  }
  
  // Attack the player using either dash or shooting magic balls
  public void handleAttack() {
     if (dmgTimer <= 0) {
      // if near, dash into player and try to hit them and damage them
      // otherwise, shoot player
      if(isNear(player, 500)) {
        println("ENTITY ACTION: Enemy dashing...");
        dash();
      }
      else if(isNear(player, 1920)) {
        shoot();
      }
     }
     else if(attackRecoverTimer > 0 && vel.x < 5) {  // Recovery time, it's a big workout to attack the player!
       //vel = new PVector(0, 0);
       attackRecoverTimer--;
     }
     else if(attackRecoverTimer == 0)  // Reset velocity after recovery time is over
       vel = maxVel;
     if(attackRecoverTimer <= 0 && dmgTimer >= 0)  // Deal damage every someodd seconds
       dmgTimer--;
     handleDash();
  }
  
  // Shoot magic/plasma balls
  public void shoot() {
    if(dmgTimer > -30) {  // Stand still to act like enemy is charging up plasma ball
      vel = new PVector(0, 0);
      shooting = true;
      dmgTimer--;
    }
    else {  // Shoot the plasma
      println("ENTITY ACTION: Shooting plasma...");
      PVector plasmaPos = new PVector(this.pos.x, this.pos.y);
      // Calculating velocity
      PVector plasmaVel = PVector.fromAngle(calcPlasmaAngle());
      plasmaVel.mult(vel1);
      if(playerRightOfEnemy()) {
        plasmaVel.y = -plasmaVel.y;
        println("Player is right of enemy, flipping plasma velocity..."); 
      }
      if(playerAboveEnemy() && playerRightOfEnemy()) {
        plasmaVel.y = -plasmaVel.y;
        plasmaVel.x = plasmaVel.x;
        println("Player is above enemy, flipping plasma velocity..."); 
      }
      int plasmaDmg = 1;
      float plasmaRot = degrees(angleBetween(this.pos, player.pos));  // Calculating sprite rotation
      plasmaBalls.add(new Plasma(plasmaPos, plasmaVel, plasmaDmg, plasmaRot));
      dmgTimer = 240;
      attackRecoverTimer = 30;
      shooting = false;
    }
  }
  
  // Update movement of plasma and deal damage to player if it hits
  public void handlePlasmas() {
    for (int i = 0; i < plasmaBalls.size(); i++) {
      Plasma p = plasmaBalls.get(i);
      p.update();
        
      if(p.isHit(player) && player.isAlive && p.isAlive) {
        println("ENTITY ACTION: Plasma hit player.");
        player.decHP(p.dmg);
        p.vel = new PVector(0, 0);
        p.dyingTimer += 30;
        p.isAlive = false;
      }
      if(p.isHit(player) && player.isAlive && !p.isAlive) {
        p.pos.add(player.vel);
      }
      if(p.isHit(player) && !player.isAlive && !p.isAlive && !player.dying) {
        p.dyingTimer = 30;
      }

      if(!p.isAlive && p.dyingTimer == 0) {
        plasmaBalls.remove(p);
        println("ENTITY: Plasma died.");
      }
    }
  }
  
  // Decrease player health if enemy dash was successful!
  public void handleDash() {
    if(isNear(player, 0) && player.dmgdTimer > 90)
      player.decHP(1);
  }
  
  // Render the plasma ball sprite
  public void renderPlasma() {
   for (int i = 0; i < plasmaBalls.size(); i++) {
      plasmaBalls.get(i).renderSprite();
   }
  }
  
  // Calculate the trajectory of the plasma (this took me an entire day to get it consistent)
  public float calcPlasmaAngle() {
    float theta;
    float g = acclGravity.y;
    // Bottom middle
    PVector pPos = new PVector(player.pos.x, player.pos.y + player.dim.y/2);
    PVector ePos = new PVector(this.pos.x, this.pos.y + this.dim.y/2);
    PVector dist = PVector.sub(pPos, ePos);
    PVector deltaDist = new PVector(abs(dist.x), abs(dist.y));  // Overall dist between player and enemy
    dist.y = dist.y * -1;
    println(dist);
    
    // Set a certain velocity for the ball depending on deltaDist
    float deltaDistTotal = deltaDist.x + deltaDist.y;
    if (deltaDistTotal > 1000)
      vel1 = 45;
    else if (deltaDistTotal > 900)
      vel1 = 42.5f;
    else if (deltaDistTotal > 800)
      vel1 = 40;
    else if (deltaDistTotal > 700)
      vel1 = 35;
    else if (deltaDistTotal > 600)
      vel1 = 32.5f;
    else if (deltaDistTotal > 500)
      vel1 = 30;
    else if (deltaDistTotal > 400)
      vel1 = 25;
    else if (deltaDistTotal > 300)
      vel1 = 22.5f;
    else if (deltaDistTotal > 200)
      vel1 = 20;
    else if (deltaDistTotal > 100)
      vel1 = 17.5f;
    else if (deltaDistTotal < 100)
      vel1 = 15;
    
    // Some projectile motion physics stuff
    float a = (-g * pow(dist.x, 2) / pow(vel1, 2)) - dist.y;
    float b = sqrt(pow(dist.y, 2) + pow(dist.x, 2));
    theta = (acos(a/b) - atan(dist.x/dist.y)) / 2;
    float gamma = degrees(angleBetween(pPos, ePos));
    if(playerRightOfEnemy()) {  // Ensure plasma is going in the right direction :>
      gamma = map(gamma, 90, 180, 0, 90);
      return theta + radians(gamma);
    }
    else  // just do it if it's on the left!
      return theta - radians(gamma);
  }
  
  // Determines where the enemy is in relation to the player
  public boolean playerBelowEnemy() {
    return player.pos.y + dim.y/2 - this.pos.y + dim.y/2 > 0;  
  }
  
  public boolean playerAboveEnemy() {
    return player.pos.y + dim.y/2 - this.pos.y + dim.y/2 < 0;  
  }
  
  public boolean playerLeftOfEnemy() {
    return player.pos.x - this.pos.x < 0;
  }
  
  public boolean playerRightOfEnemy() {
    return player.pos.x - this.pos.x > 0;
  }

  // Kills enemy
  public void handleDeath() {
    // Despawn timer
    // Fade away
    // Change sprite?
    vel = new PVector(0, 0);

    if(!isAlive && dying) {
      moveWithChar();
      if(dyingTimer >= 0)
        dyingTimer--;
      if(dyingTimer <= 30 && dyingTimer > 0)
        alpha -= 2;
      if(dyingTimer == 30 && (level == LVL_1 || level == LVL_2) && !checkAliveEnemies()) {
        PImage[] gemSprite = sprGem;
        PVector dim = new PVector(gemSprite[0].width, gemSprite[0].height);
        PVector pos = new PVector(this.pos.x, this.pos.y);
        int range = 50;
        interactables.add(new Gem(pos, dim, gemSprite, range));
      }
      if(dyingTimer <= 0) {
        println("ENTITY: Enemy is dead. Removing from ArrayList...");
        enemies.remove(this);
      }
    }
    else if(!isAlive && !dying) {
      dyingTimer += 120;
      dying = true;
      println("ENTITY: Enemy is dying...");
    }
  }
  
  // Kills enemy before handleDeath :>
  public void handleHealth() {
    if(health.x <= 0)
      isAlive = false;
  }
  
  // Sticks the enemy to the ground
  public void handleGravity() {
    if (grounded) {
      vel.y = 0;
      this.pos.y = height - dim.y/2 - groundLevel; 
    }
    else
      accl(acclGravity);
  }
  
  // Shows the enemy
  public void renderSprite() {
    pushMatrix();
    translate(pos.x, pos.y);
    isSpriteFlipped();
    updateSpriteStates();
    if(!spriteFlipped)
      scale(-1, 1);
    tint(255, alpha);
    image(handleSpriteStates(), 0, 0);
    //renderBB();
    popMatrix();
  }
  
  // Handles animation
  public PImage handleSpriteStates() {
    if (!paused) { // Lock sprite position when paused
      if(frameCount % animationRate == 0) {
        if(currFrame < activeFrames.length-1)
          if(spriteState == DIE && currFrame == activeFrames.length - 2)
            return spriteCurrent;
          else
            currFrame++;
        else
          currFrame = 0;
        spriteCurrent = activeFrames[currFrame];
      }
    }
    return spriteCurrent;
  }
  
  // Handles different animation states - similar to character (see character comments)
  public void updateSpriteStates() {
    dim = new PVector(activeFrames[0].width, activeFrames[0].height);
    spriteState = IDLE;
    if(vel.x != 0)
      spriteState = WALK;
    if(shooting || (spriteStatePrev == ATTACK && currFrame != sprWitchAtk.length - 1 && attackRecoverTimer > 0))
      spriteState = ATTACK;
    if(!isAlive)
      spriteState = DIE;
          
    if(spriteState != spriteStatePrev) {
      switch(spriteState) {
        case(IDLE):
          activeFrames = sprWitchIdle;
          animationRate = 30;
          currFrame = 0;
          spriteCurrent = activeFrames[currFrame];
          break;
        case(WALK):
          activeFrames = sprWitchMove;
          animationRate = 8;
          currFrame = 0;
          spriteCurrent = activeFrames[currFrame];
          break;
        case(ATTACK):
          activeFrames = sprWitchAtk;
          animationRate = 3;
          dim = new PVector(activeFrames[0].width, activeFrames[0].height);
          currFrame = 0;
          spriteCurrent = activeFrames[currFrame];
          break;
        case(DIE):
          activeFrames = sprWitchDie;
          animationRate = 8;
          currFrame = 0;
          spriteCurrent = activeFrames[currFrame];
          break;        
      }
      spriteStatePrev = spriteState;
    }
    
    switch(spriteState) {
      case(IDLE):
        bb[0] = new PVector(activeFrames[currFrame].width, activeFrames[currFrame].height);
        bb[1] = new PVector(0, 0);
        break;
      case(WALK):
        bb[0] = new PVector(activeFrames[currFrame].width/1.5f, activeFrames[currFrame].height);
        bb[1] = new PVector(0, 0);    
        break;
      case(ATTACK):
        bb[0] = new PVector(44, 128);
        bb[1] = new PVector(0, 0);
        break;
      case(DIE):
        bb[0] = new PVector(activeFrames[currFrame].width, activeFrames[currFrame].height);
        bb[1] = new PVector(0, 0);
        break;        
    }
  }
  
  
  public float healthPercentage(boolean accountForShield) {
    if(accountForShield) {
      float totalHealth = health.x + health.y;
      float totalMaxHealth = maxHealth.x + maxHealth.y;
      return totalHealth / totalMaxHealth * 100;
    }
    else
      return health.x / maxHealth.x * 100;
  }
  
  public void decHP(int dmg) {  // Decreases character's health
    if (health.y - dmg > 0)
      health.y -= dmg;
    else if (health.y - dmg < 0 && health.y > 0) {
      while (health.y > 0) {
        health.y--;
        dmg--;
      }
      health.x -= dmg;
    } 
    else
      health.x -= dmg;
  }
  
  // Fixes a bug where gem drops twice when two enemies are killed from the same arrow in the same frame
  public boolean checkAliveEnemies() {
    for(int i = 0; i < enemies.size(); i++) {
      if(enemies.get(i).dyingTimer > this.dyingTimer || !enemies.get(i).dying)
        return true;
    }
    return false;
  }
}
// Gem: a cool shiny item that helps player progress to Level Three

class Gem extends Item {
  
  PImage[] spriteAnim, spriteAnimNear, spriteAnimHover;
  int spriteState;
  int spriteStatePrev;
  PImage spriteCurrent;
  
  PImage[] activeFrames;
  int currFrame = 0;
  int animationRate = 10;
  
  Gem(PVector pos, PVector dim, PImage[] sprite, int range) {
    super(pos, dim, sprite[0], range);
    this.spriteAnim = sprite;
    this.spriteCurrent = sprite[0];
    this.activeFrames = sprite;
    this.spriteAnimNear = new PImage[sprite.length];
    this.spriteAnimHover = new PImage[sprite.length];
    for (int i = 0; i < sprite.length; i++) {
      this.spriteAnimNear[i] = createSpriteOutline(spriteAnim[i], outlineWhite, 3);
      this.spriteAnimHover[i] = createSpriteOutline(spriteAnim[i], outlineYellow, 3);
    }
  }
  
  // Handle animation states and animation frames
  public PImage handleSpriteStates() {
    activeFrames = spriteAnim;
    if(isNear)
      activeFrames = spriteAnimNear;
    if(isHover())
      activeFrames = spriteAnimHover;
    // Check health to change sprite accordingly
    if (!paused) { // Lock sprite position when paused
      if(frameCount % animationRate == 0) {
        if(currFrame < activeFrames.length-1)
          currFrame++;
        else
          currFrame = 0;
        spriteCurrent = activeFrames[currFrame];
      }
    }
    return spriteCurrent;
  }
  
  // Adds sound to pickup
  public void pickUp(Char c) {
    c.inventory.add(this);
    playSound(sfxGem[0]);
    interactables.remove(this);
  }
}
// Interactable: Something that the player can interact with. 
// Actual interactables should be subclasses as they have unique properties

class Interactable {
  
  PVector pos, dim;
  int outlineWhite = color(255, 255, 255);
  int outlineYellow = color(255, 220, 41);
  PImage sprite, spriteNear, spriteHover;
  float range;
  boolean isNear;
  int alpha = 60;
  
  Interactable(PVector pos, PVector dim, PImage sprite, float range) {
    this.pos = pos;
    this.dim = dim;
    this.range = range;
    this.sprite = sprite;
    //sprite.resize(int(dim.x), int(dim.y));
    spriteNear = createSpriteOutline(sprite, outlineWhite, 3);
    spriteHover = createSpriteOutline(sprite, outlineYellow, 3);
  }
  
  public void update() {
    moveWithChar();
    isNear(player, range);
  }
  
  public void moveWithChar() {
    if(!player.nearWall)
      pos.x -= player.vel.x * bgSpeed;
  }
  
  // Checks if character is near the object
  public void isNear(MovingObject c, float range) {
    PVector relLoc = new PVector(abs(pos.x - c.pos.x), abs(pos.y - c.pos.y));
    PVector isNearRange = new PVector(dim.x/2 + c.dim.x/2 + range, dim.y/2 + c.dim.y/2 + range);
    if (relLoc.x < isNearRange.x && relLoc.y < isNearRange.y)
      isNear = true;
    else
      isNear = false;
  }
  
  // A boolean version of the method above
  public boolean isNearBool(MovingObject c, float range) {
    PVector relLoc = new PVector(abs(pos.x - c.pos.x), abs(pos.y - c.pos.y));
    PVector isNearRange = new PVector(dim.x/2 + c.dim.x/2 + range, dim.y/2 + c.dim.y/2 + range);
    return relLoc.x < isNearRange.x && relLoc.y < isNearRange.y; 
  }
  
  // A version that uses interactables instead of characters
  public boolean isNearInteractableBool(Interactable c, float range) {
    PVector relLoc = new PVector(abs(pos.x - c.pos.x), abs(pos.y - c.pos.y));
    PVector isNearRange = new PVector(dim.x/2 + c.dim.x/2 + range, dim.y/2 + c.dim.y/2 + range);
    return relLoc.x < isNearRange.x && relLoc.y < isNearRange.y; 
  }
  
  // Is the mouse hovering over the interactable
  public boolean isHover() {
    int mx = mouseX;
    int my = mouseY;
    return abs(pos.x - mx) < dim.x/2 && abs(pos.y - my) < dim.y/2;
  }
  
  // Did the player click on the interactable
  public boolean isClicked() {
    return isHover() && interact && isNear; 
  }
  
  // Did the player click on the interactable but doesn't need to be near it (for portal piece)
  public boolean isClickedNotNear() {
    return isHover() && interact; 
  }
  
  // Render the beautile object
  public void renderSprite() {
    pushMatrix();
    translate(pos.x, pos.y);
    //rectMode(CENTER);
    //fill(255, alpha);
    //stroke(0, alpha);
    //strokeWeight(3);
    //rect(0, 0, 100, 100);
    imageMode(CENTER);
    tint(255, alpha);
    image(handleSpriteStates(), 0, 0);
    popMatrix();
  }
  
  // Handle the different states of the sprites
  public PImage handleSpriteStates() {
    PImage sprite = this.sprite;
    if(isNear)
      sprite = spriteNear;
    if(isHover())
      sprite = spriteHover;
    return sprite; 
  }
  
  // Create an outlined version of the sprite with whatever color and thickness (pixels)
  public PImage createSpriteOutline(PImage img, int c, int weight) {
     PImage imgCopy = createImage(img.width + weight * 2, img.height + weight * 2, ARGB);
     imgCopy.copy(img, 0, 0, img.width, img.height, weight, weight, imgCopy.width - weight*2, imgCopy.height - weight*2);
     imgCopy.loadPixels();
     setPixelOutline(imgCopy, 0, weight, c);
     imgCopy.updatePixels();
     return imgCopy;
   }
  
  // The painstaking process of adding the outline pixel by pixel (this also took a day to make :>)
  public PImage setPixelOutline(PImage img, int line, int w, int c) { // Per row of pixels
    int imgW = img.width;
    int imgH = img.height;
    
    for(int j = 0; j < dim.x; j++) {  // Each pixel on the row
      int pixel = j + (line + 1) * imgW;  // Calc pos of pixel in full image array 
      
      if(pixel < dim.x * imgH) {  // Ensure it is on the row
        int r = PApplet.parseInt(red(img.pixels[pixel]));
        int g = PApplet.parseInt(green(img.pixels[pixel]));
        int b = PApplet.parseInt(blue(img.pixels[pixel]));
        int a = getAlpha(img, pixel);
        int rgb = color(r, g, b);
        
        if(a != 0 && rgb != c) {  // Filled pixel
          if((pixel - w >= 0 && alpha(img.pixels[pixel - 1]) == 0))  // If pixel behind is empty...
            for(int i = 0; i < w; i++)
              img.pixels[pixel - i - 1] = color(c);
           
          if(pixel + w <= imgW * (ceil(PApplet.parseFloat(pixel)/PApplet.parseFloat(imgW))) && getAlpha(img, pixel + 1) == 0)  // If next pixel is empty...
            for(int i = 0; i < w; i++)
              img.pixels[pixel + i + 1] = color(c);
           
          if(pixel - imgW * w >= 0 && getAlpha(img, pixel - imgW) == 0)  // If pixel above is empty...
            for(int i = 0; i < w; i++)
              img.pixels[pixel - i * imgW] = color(c);
           
          if(pixel + imgW * w <= imgW * imgH && getAlpha(img, pixel + imgW) == 0) // If pixel below is empty...
            for(int i = 0; i < w; i++)
              img.pixels[pixel + i*imgW] = color(c);
        }
      }
    }
    if(line < imgH)  // Go to next line if not finished
      return setPixelOutline(img, line + 1, w, c);
    else
      return img;  // Returned outlined image
  }
  
  // Get the alpha value of a certain pixel from a certain image
  public int getAlpha(PImage img, int pixel) {
    return PApplet.parseInt(alpha(img.pixels[pixel]));
  }
}
// Item: An interactable that can be picked up by the character
// Used for creating the gem, but can be used for other enemy drops, health packs, etc.

class Item extends Interactable {
  
  final PVector acclGravity = new PVector(0, 1);
  PVector vel = new PVector(0, 0);
  PVector acclSpawn = new PVector(0, -5);
  boolean grounded;
  
  Item(PVector pos, PVector dim, PImage sprite, int range) {
    super(pos, dim, sprite, range);
    spawn();
  }
  
  public void update() {
    super.update();
    move();
    grounded();
    handleGravity();
    if(isClicked())
      pickUp(player);
  }
  
  // Add a little fun to the spawning of the item
  public void spawn() {
    accl(acclSpawn);
  }
  
  public void move() {
    pos.add(vel);
  }
  
  public void accl(PVector force) {
    vel.add(force);
  }
  
  // Make the items have gravity so the player can pick them up
  public void handleGravity() {
    if (grounded) {
      vel.y = 0;
      this.pos.y = height - dim.y/2 - groundLevel; 
    }
    else
      accl(acclGravity);
  }
  
  // Check if item is on the ground for correcting y pos
  public void grounded() {
    if(pos.y + dim.y/2 + groundLevel >= height)
      grounded = true;
    else
      grounded = false;
  }
  
  // The character adds it to their inventory
  public void pickUp(Char c) {
    c.inventory.add(this);
    interactables.remove(this);  // Delete it from the map
  }
  
  // Remove it from the character's inventory
  public void removeMe(Char c) {
    c.inventory.remove(this);
  }
  
  
  
  
}
/* 
Moving Object: 

The base of the player, projectiles, and enemies.
Has basic physics and methods to help accomplish tasks involving their object in space.
*/

class MovingObject {
  PVector pos, vel, dim, maxVel;
  PVector[] bb = new PVector[2];  // bb[0] = bounding box size | bb[1] = bounding box location relative to center of entity
  final PVector acclGravity = new PVector(0, 1);
  boolean grounded, dying, spriteFlipped;
  boolean isAlive = true;
  float alpha = 60;
  float dyingTimer = 0;
  boolean touchingWall, nearWall;
  
  MovingObject(PVector pos, PVector vel, PVector dim, PVector[] bb) {
    this.pos = pos;
    this.vel = vel;
    this.dim = dim;
    this.bb = bb;
    this.maxVel = new PVector(vel.x * bgSpeed, vel.y);
  }
  
  public void update() {
    move();
    grounded();
  }
  
  public void move() {
    pos.add(vel);
  }
  
  public void moveWithChar() {
    if(!player.nearWall)
      pos.x -= player.vel.x * 4;
  }
  
  public void accl(PVector force) {
    vel.add(force);
  }
  
  public void grounded() {
    if(pos.y + dim.y/2 + groundLevel >= height)
      grounded = true;
    else
      grounded = false;
  }
  
  // Helps vizualize their hitbox 
  public void renderBB() {
    rectMode(CENTER);
    noFill();
    stroke(0xffFBFF1F, alpha);
    strokeWeight(3);
    rect(bb[1].x, bb[1].y, bb[0].x, bb[0].y); 
  }
  
  // Is the entity hit from another entity?
  public boolean isHit(MovingObject obj) {
    return abs(this.pos.x + this.bb[1].x - obj.pos.x - obj.bb[1].x) < this.bb[0].x/2 + obj.bb[0].x/2 && abs(this.pos.y + this.bb[1].y - obj.pos.y - obj.bb[1].y) < this.bb[0].y/2 + obj.bb[0].y/2;
  }
  
  // Is the entity near another entity in a certain range?
  public boolean isNear(MovingObject obj, float range) {
    return abs(this.pos.x + this.bb[1].x - obj.pos.x + obj.bb[1].x) < this.bb[0].x/2 + obj.bb[0].x/2 + range && abs(this.pos.y + this.bb[1].y - obj.pos.y + obj.bb[1].y) < this.bb[0].y/2 + obj.bb[0].y/2 + range;
  }
  
  // Check to see if the sprite needs to be flipped
  public boolean isSpriteFlipped() {
    if(vel.x > 0)
      spriteFlipped = true;
    else if(vel.x < 0)
      spriteFlipped = false;
    return spriteFlipped;
  }
  
  // Calculate the angle between two points
  public float angleBetween(PVector p1, PVector p2) {
    PVector dist = PVector.sub(p1, p2); // Calculating distance between two points
    return atan2(dist.y, dist.x);  // Calculating angle
  } 
}
// Plasma: The project that enemies use to fight against the player.

class Plasma extends Projectile {
  
  PImage spriteCurrent;
  PImage[] activeFrames;
  int currFrame = 0;
  int animationRate = 5;
  
  Plasma(PVector pos, PVector vel, int dmg, float rot) {
    super(pos, vel, dmg, rot, new PVector(10, 38), new PVector[]{new PVector(10, 38), new PVector(0,0)});
    this.activeFrames = sprPlasma;
    this.spriteCurrent = sprPlasma[0];
  }
  
  public void renderSprite() {
    pushMatrix();
    translate(pos.x, pos.y);
    tint(255, alpha);
    image(handleSpriteStates(), 0, 0);
    popMatrix();
  }
  
  // Handle its basic animation
  public PImage handleSpriteStates() {
    // Check health to change sprite accordingly
    if (!paused) { // Lock sprite position when paused
      if(frameCount % animationRate == 0) {
        if(currFrame < activeFrames.length-1)
          currFrame++;
        else
          currFrame = 0;
        spriteCurrent = activeFrames[currFrame];
      }
    }
    return spriteCurrent;
  }
  
  // Kill it slowly if it's not alive
  public void handleDeath() {
    if(!isAlive && dying) {
      if(dyingTimer > 0)
        dyingTimer--;
      if(dyingTimer <= 60 && dyingTimer >= 0)
        alpha--;
    }
    else if(!isAlive && !dying) {
      dyingTimer += 30;
      dying = true;
      println("ENTITY: Plasma is dying...");
    }
  }
  
}
/*
Portal:

An interactable object that is a barrier between levels.
The player must put the portal back together with the use 
of the broken portal piece or gems depending on the level.
*/
class Portal extends Interactable {
  
  // States of the portal
  final int BROKEN = 0;
  final int PIECE_NEAR = 1;
  final int PIECE_HOVER = 2;
  final int COMPLETE = 3;
  
  int state;
  boolean opened, handledSound, nextLevel;
  
  PImage spriteCurrent;
  PImage[] activeFrames, sprPortalNear, sprPortalHover;
  PImage[] sprFrame, sprOpen, sprIdle;
  int currFrame = 0;
  int animationRate = 5;
  int currLevel;
  
  PortalPiece portalPiece;
  
  Portal(PVector pos, PVector dim, PImage[] sprFrame, PImage[] sprOpen, PImage[] sprIdle) {
    super(pos, dim, sprFrame[0], 100);
    this.state = BROKEN;
    this.activeFrames = sprOpen;
    this.spriteCurrent = sprOpen[0];
    this.sprFrame = sprFrame;
    this.sprOpen = sprOpen;
    this.sprIdle = sprIdle;
    this.sprPortalNear = new PImage[sprIdle.length];
    this.sprPortalHover = new PImage[sprIdle.length];
    for (int i = 0; i < sprIdle.length; i++) {
      this.sprPortalNear[i] = createSpriteOutline(sprIdle[i], outlineWhite, 5);
      this.sprPortalHover[i] = createSpriteOutline(sprIdle[i], outlineYellow, 5);
    }
    this.currLevel = level;
  }
  
  public void update() {
    // Spawn the portal piece at the right moment on Level One
    if(narrOneLevel == LVL_6 && portalPiece == null && state == BROKEN && level == LVL_1)  
      createPortalPiece();
      
    moveWithChar();
    updatePortal();
    handleSonuds();
    isNear(player, range);
    
    // I think this is useless but i'll leave it in just incase it breaks something (as well as the ones in A04_Switches)
    switch(state) {  
      case(BROKEN):
        break;
      case(PIECE_NEAR):
        break;
      case(PIECE_HOVER):
        break;
      case(COMPLETE):
        break;
    }
    
    // Stop the sounds when the level changes and break it again so the player doesn't think they can go back through
    if(currLevel != level && !nextLevel) {
      sfxPortal[0].pause();
      sfxPortal[1].pause();
      state = BROKEN;
      nextLevel = true;
    }
  }
  
  public void renderSprite() {
    pushMatrix();
    translate(pos.x, pos.y);
    if(opened)
      updateSpriteStates();
    imageMode(CENTER);
    tint(255, 60);
    if(state == COMPLETE)  // Only animate if it's complete
      image(handlePortalAnimation(), 0, 0);
    else {  // Static images otherwise :<
      image(sprFrame[state], 0, 0);
    }
    popMatrix();
    if(state != COMPLETE && portalPiece != null)
      portalPiece.renderSprite();  // Render the portal piece as well
  }
  
  // Handle the animation states/frames
  public PImage handlePortalAnimation() {
    if (!paused) { // Lock sprite position when paused
      if(frameCount % animationRate == 0) {
        if(currFrame < activeFrames.length-1)
          currFrame++;
        else {
          if(activeFrames == sprOpen) {
            activeFrames = sprIdle;
            opened = true; 
          }
          currFrame = 0;
        }
        spriteCurrent = activeFrames[currFrame];
      }
    }
    return spriteCurrent;
  }
  
  // Change to the outlined versions if player is near
  public void updateSpriteStates() {
    if(state == COMPLETE) {
      if(isNear)
        activeFrames = sprPortalNear;
      if(isHover())
        activeFrames = sprPortalHover; 
    }
  }
  
  // Handle the sounds for opening and the portal idling
  public void handleSonuds() {
    if(state == COMPLETE && !handledSound) {
      playSound(sfxPortal[0]);
      playSound(sfxPortal[1]);
      sfxPortal[1].shiftGain(-50, -5, 7000);
      sfxPortal[1].loop(99); 
      handledSound = true;
    } 
  }
  
  // Handle the states of the portal depending on how it's being put together
  public void updatePortal() {
    // The portal piece way 
    if(portalPiece != null) {
      state = BROKEN;
      portalPiece.update();
      if(portalPiece.onMouse)
        state = PIECE_NEAR;
      if(portalPiece.isNearInteractableBool(this, portalPiece.range))
        state = PIECE_HOVER;
      if(isHover() && portalPiece.onMouse) {
        state = COMPLETE;
        portalPiece = null;  // Delete the piece. We don't need you anymore :>
      }
    }
    
    // The gem way
    if(player.getGemCount() >= 2 && gameTwoLevel == LVL_5) {
      state = BROKEN;
      if(isNear)
        state = PIECE_NEAR;
      if(isHover())
        state = PIECE_HOVER;
      if(isHover() && interact && isNear) {
        state = COMPLETE;
        int gemCount = 0;
        for(int i = 0; i < player.inventory.size(); i++) {  // Remove the gems once they get put into the portal
          if(player.inventory.get(i).sprite == sprGem[0]) {
            player.inventory.get(i).removeMe(player);
            gemCount++;
          }
          if(gemCount == 2)
            break;
        }
      }
    }
  }
  
  // Initialize the portal piece
  public void createPortalPiece() {
    PVector piecePos = new PVector(pos.x - random(500, 2000), height/2);
    PVector pieceDim = new PVector(184, 64);
    PImage pieceSprite = sprFrame[3];
    int pieceRange = 100;
    portalPiece = new PortalPiece(piecePos, pieceDim, pieceSprite, pieceRange); 
  }
  
  // Ensure the portal is fully opened before going through
  public boolean isClicked() {
    return isHover() && interact && isNear && opened; 
  }
  
}
// Portal Piece: An item you can't put in your inventory, but pick up and fix the portal with!

class PortalPiece extends Item {
  
  boolean onMouse;
  
  PortalPiece(PVector pos, PVector dim, PImage sprite, int range) {
    super(pos, dim, sprite, range);
  }
  
  // Update literally everything
  public void update() {
    moveWithChar();
    isNear(player, range);
    if(onMouse)  // If the player is trying to move the piece
      moveWithMouse();
    else {  // Otherwise, just do regular item things
      move();
      grounded();
      handleGravity();
    }
    if(isClickedNotNear())  // Check for the mouse
      onMouse = true;
    else
      onMouse = false;
  }
  
  // Move the portal piece relative to the player's mouse
  public void moveWithMouse() {
    pos = new PVector(mouseX, mouseY);  
  } 
}
/*
Projectile Class:
Something that can hit other entities
*/

class Projectile extends MovingObject {
  
  int dmg;
  float rot;
  
  Projectile(PVector pos, PVector vel, int dmg, float rot, PVector dim, PVector[] bb) {
    super(pos, vel, dim, bb); 
    this.dmg = dmg;
    this.rot = rot;
  }
  
  public void update() {
    super.update();
    handleFloor();
    handleDeath();
  }
  
  public void move() {
    super.move();
    moveWithChar();
  }
  
  public void handleFloor() {
    if (grounded && isAlive) {
      vel.y = 0;
      vel.x = 0;
      this.pos.y = height - dim.y/2 + 4 - groundLevel;
      isAlive = false;
    }
    else if(isAlive)
      accl(acclGravity);
  }
  
  public void handleDeath() {
    if(!isAlive && dying) {
      if(dyingTimer > 0)
        dyingTimer--;
      if(dyingTimer <= 60 && dyingTimer >= 0)
        alpha--;
    }
    else if(!isAlive && !dying) {
      dyingTimer += 600;
      dying = true;
      println("ENTITY: Projectile is dying...");
    }
  }
  
  // Ensure proper rotation of the sprite
  public float calcRot() {
    return vel.heading();
  }
}
// UI: Grouping all screens into a UI class just because I can :>

class UI {
  Char p;
  float winAlpha = 0;  // The alpha value for fading in the win screen
  
  UI(Char p) {
    this.p = p;
  }
  
  // Pause Screen
  public void renderPauseScreen() {
    pushMatrix();
    rectMode(CORNER);
    noStroke();
    fill(0, 20);
    rect(0, 0, width, height);
    translate(200, 250);
    textAlign(LEFT, BOTTOM);
    textFont(fontBold);
    textSize(72);
    fill(250);
    text("PAUSED", 0, 0);
    translate(385, -72/1.75f);
    tint(255, 60);
    image(spritesOther[0], 0, 0);
    popMatrix();
    if(showControls)
      renderControlScreen();
  }
  
  // Win Screen
  public void renderWinScreen() {
    if(winAlpha < 60)
      winAlpha += 0.33f;
    pushMatrix();
    translate(width/2, height/4);
    textAlign(CENTER, CENTER);
    textFont(fontBold);
    textSize(96);
    fill(255, winAlpha);
    text("You won!", 0, 0);
    popMatrix();
    
    if(winAlpha >= 60 && state == WON) {  // Show buttons after fade-in
      quit.show();
      menu.show();
    }
    else {
      restartLevel.hide();
      restart.hide();
      quit.hide();
      menu.hide();
    }
  }
  
  // Lose Screen
  public void renderLoseScreen() {
    pushMatrix();
    translate(width/2, height/4);
    textAlign(CENTER, CENTER);
    textFont(fontBold);
    textSize(96);
    if(level == LVL_2)
      fill(0, 60 - player.alpha);
    else
      fill(255, 60 - player.alpha);
    text("You Died.", 0, 0);
    popMatrix();
    
    // Show buttons after fade-in
    if(player.alpha <= 0 && !player.isAlive) {  //Fade-in is based off of the player's own alpha value  
      restartLevel.show();
      restart.show();
    }
    else {
      restartLevel.hide();
      restart.hide();
    }
  }
  
  // Health & Shield bar
  public void renderHUD() {
    pushMatrix();
    rectMode(CORNER);
    translate(50, 50);
    fill(map(p.health.x, 0, p.maxHealth.x, 100, 255), 0, 0);  // Health bar
    noStroke();
    int rectWidth = PApplet.parseInt(map(p.health.x, 0, p.maxHealth.x, 0, 500));
    rect(0, 0, rectWidth, 50);
    
    // Health bar outline 
    noFill();
    strokeWeight(5);
    if(level == LVL_3)
      stroke(255);
    else
      stroke(0);
    rect(0, 0, 500, 50);
    
    translate(0, 75);
    fill(0xff6AEAFF);
    noStroke();
    rectWidth = PApplet.parseInt(map(p.health.y, 0, p.maxHealth.y, 0, 500));  // Shield bar
    rect(0, 0, rectWidth, 50);
    
    // Shield bar outline
    noFill();
    strokeWeight(5);
    if(level == LVL_3)
      stroke(255);
    else
      stroke(0);
    rect(0, 0, 500, 50);
    popMatrix();
  }
  
  // Start screen
  public void renderStartScreen() {
    renderBackground();
    pushMatrix();
    translate(200, 250);
    textAlign(LEFT, BOTTOM);
    textFont(fontBold);
    textSize(72);
    fill(250);
    text("The Archer", 0, 0);
    translate(450, -72/1.5f);
    tint(255, 60);
    image(spritesOther[0], 0, 0);
    popMatrix();
    if(showControls)
      renderControlScreen();
  }
  
  // Controls image
  public void renderControlScreen() {
    pushMatrix();
    translate(width-73-spritesUI[0].width, 73);
    imageMode(CORNER);
    image(spritesUI[0], 0, 0);
    translate(spritesUI[0].width/2, 50);
    popMatrix();
  }
  
  // Render the dialogue with the title, the content, and the positions. Was going to do a fade animation but ran out of time
  public void renderNarrative(String speaker, String text, PVector pos, PVector dim, int padding, int alpha) {
    renderTextBox(pos, dim, padding, alpha);
    writeTitle(pos, dim, speaker, padding, alpha);
    writeText(pos, dim, text, padding, alpha);
  }
  
  // Render the text box
  public void renderTextBox(PVector pos, PVector dim, int padding, int alpha) {
    fill(255, alpha);
    stroke(0, alpha);
    strokeWeight(4);
    rectMode(CENTER);
    pushMatrix();
    translate(pos.x, pos.y);
    rect(0, 0, dim.x, dim.y);
    popMatrix();
  }
  
  // Render the title/speaker
  public void writeTitle(PVector pos, PVector dim, String speaker, int padding, int alpha) {
    textAlign(LEFT, TOP);
    textFont(fontBold);
    textSize(36);
    fill(0, alpha);
    pushMatrix();
    translate(pos.x - dim.x/2 + padding, pos.y - dim.y/2 + padding);
    text(speaker, 0, 0);
    popMatrix();
  }
  
  // Render the dialogue
  public void writeText(PVector pos, PVector dim, String text, int padding, int alpha) {
    textAlign(LEFT, TOP);
    textFont(font);
    textSize(24);
    fill(0, alpha);
    pushMatrix();
    translate(pos.x - dim.x/2 + padding, pos.y - dim.y/2 + padding*2 + 36);
    text(text, 0, 0);
    popMatrix();
  }
  
  // Show the button to advance the dialogue. Alpha value shows when you can press it.
  public void showKeyE(int alpha) {
    pushMatrix();
    imageMode(CORNER);
    translate(width - spritesUI[1].width - narrPadding, narrPadding);
    tint(255, alpha);
    image(spritesUI[1], 0, 0);
    popMatrix();
  }
  
}
  public void settings() {  size(1920, 1080, P2D); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "The_Archer" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
